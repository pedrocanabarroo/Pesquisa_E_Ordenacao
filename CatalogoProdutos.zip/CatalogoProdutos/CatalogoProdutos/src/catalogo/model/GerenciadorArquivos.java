package catalogo.model;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Leitura e escrita dos arquivos texto de produtos. */
public class GerenciadorArquivos {

    /** Lê o arquivo para uma ArrayList, ignorando a primeira linha (cabeçalho). */
    public static List<Produto> ler(String caminho) throws IOException {
        List<Produto> lista = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(caminho), StandardCharsets.UTF_8)) {
            br.readLine(); // descarta o cabeçalho: id;nome;categoria;preco;estoque
            String linha;
            while ((linha = br.readLine()) != null) {
                if (linha.isBlank()) {
                    continue;
                }
                String[] c = linha.split(";");
                lista.add(new Produto(
                        Integer.parseInt(c[0].trim()),
                        c[1],
                        c[2],
                        Double.parseDouble(c[3].trim()), // ponto como separador decimal
                        Integer.parseInt(c[4].trim())));
            }
        }
        return lista;
    }

    /** Grava a lista, na ordem atual, no mesmo formato do arquivo de entrada. */
    public static void exportar(List<Produto> lista, String caminho) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(caminho), StandardCharsets.UTF_8)) {
            bw.write("id;nome;categoria;preco;estoque");
            bw.newLine();
            for (Produto p : lista) {
                bw.write(p.toLinhaArquivo());
                bw.newLine();
            }
        }
    }
}

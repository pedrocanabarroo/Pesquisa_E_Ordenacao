package catalogo.model;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Algoritmos de ordenação implementados à mão + Comparators por campo. */
public class Ordenador {

    // ---------- Comparators ----------

    public static Comparator<Produto> porNome() {
        return (a, b) -> a.getNome().compareToIgnoreCase(b.getNome());
    }

    public static Comparator<Produto> porPreco() {
        return (a, b) -> Double.compare(a.getPreco(), b.getPreco());
    }

    public static Comparator<Produto> porId() {
        return (a, b) -> Integer.compare(a.getId(), b.getId());
    }

    // ---------- Algoritmo simples: Bubble Sort  O(n²) ----------

    /**
     * Bubble Sort com parada antecipada (se uma passada não trocar nada, já está ordenado).
     *
     * @param limiteMs tempo máximo em milissegundos (0 = sem limite)
     * @return true se terminou; false se foi interrompido por excesso de tempo
     */
    public static boolean bubbleSort(List<Produto> lista, Comparator<Produto> c, long limiteMs) {
        long inicio = System.nanoTime();
        long limiteNs = limiteMs * 1_000_000L;
        int n = lista.size();

        for (int i = 0; i < n - 1; i++) {
            boolean trocou = false;
            for (int j = 0; j < n - 1 - i; j++) {
                // se o elemento da esquerda for "maior", troca com o da direita
                if (c.compare(lista.get(j), lista.get(j + 1)) > 0) {
                    Collections.swap(lista, j, j + 1);
                    trocou = true;
                }
            }
            if (!trocou) {
                break; // já ordenado
            }
            // verifica o tempo a cada passada completa
            if (limiteMs > 0 && System.nanoTime() - inicio > limiteNs) {
                return false;
            }
        }
        return true;
    }

    // ---------- Algoritmo eficiente: Merge Sort  O(n log n) ----------

    /** Merge Sort (estável). Trabalha num vetor auxiliar e devolve o resultado à lista. */
    public static void mergeSort(List<Produto> lista, Comparator<Produto> c) {
        Produto[] v = lista.toArray(new Produto[0]);
        Produto[] aux = new Produto[v.length];
        dividir(v, aux, 0, v.length - 1, c);
        for (int i = 0; i < v.length; i++) {
            lista.set(i, v[i]);
        }
    }

    /** Divide o vetor ao meio recursivamente e depois intercala as metades. */
    private static void dividir(Produto[] v, Produto[] aux, int ini, int fim, Comparator<Produto> c) {
        if (ini >= fim) {
            return; // 0 ou 1 elemento: já ordenado
        }
        int meio = (ini + fim) >>> 1;
        dividir(v, aux, ini, meio, c);
        dividir(v, aux, meio + 1, fim, c);
        intercalar(v, aux, ini, meio, fim, c);
    }

    /** Junta duas metades já ordenadas [ini..meio] e [meio+1..fim]. */
    private static void intercalar(Produto[] v, Produto[] aux, int ini, int meio, int fim,
                                   Comparator<Produto> c) {
        int i = ini;       // percorre a metade esquerda
        int j = meio + 1;  // percorre a metade direita
        int k = ini;       // posição no vetor auxiliar

        while (i <= meio && j <= fim) {
            // <= 0 mantém a estabilidade (empate fica a esquerda primeiro)
            if (c.compare(v[i], v[j]) <= 0) {
                aux[k++] = v[i++];
            } else {
                aux[k++] = v[j++];
            }
        }
        while (i <= meio) {
            aux[k++] = v[i++];
        }
        while (j <= fim) {
            aux[k++] = v[j++];
        }
        for (k = ini; k <= fim; k++) {
            v[k] = aux[k];
        }
    }
}

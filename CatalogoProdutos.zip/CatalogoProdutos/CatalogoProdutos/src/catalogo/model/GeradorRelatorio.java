package catalogo.model;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/** Gera o arquivo relatorio.txt com os tempos para 1.000, 10.000 e 50.000 registros. */
public class GeradorRelatorio {

    private static final int[] TAMANHOS = {1000, 10000, 50000};
    private static final int REPETICOES = 1000;
    private static final long LIMITE_MS = 120_000; // 2 minutos para o algoritmo simples

    private static final String[] OPERACOES = {
        "Ordenação simples (por preço)",
        "Ordenação eficiente (por preço)",
        "Referência: List.sort (por preço)",
        "Busca linear por id (média)",
        "Busca binária por id (média)",
        "Busca por HashMap (média)",
        "Construção do HashMap"
    };

    /** Executa todas as medições, grava o arquivo e devolve o texto do relatório. */
    public static String gerar(String caminhoSaida) throws IOException {
        String[][] tabela = new String[OPERACOES.length][TAMANHOS.length];

        for (int t = 0; t < TAMANHOS.length; t++) {
            List<Produto> original =
                    GerenciadorArquivos.ler("produtos_" + TAMANHOS[t] + ".txt");

            // --- Ordenação simples (cópia, para não alterar a lista original) ---
            List<Produto> copia = new ArrayList<>(original);
            long ini = System.nanoTime();
            boolean concluiu = Ordenador.bubbleSort(copia, Ordenador.porPreco(), LIMITE_MS);
            long dur = System.nanoTime() - ini;
            tabela[0][t] = concluiu ? Cronometro.formatar(dur) : "não concluído (> 2 min)";

            // --- Ordenação eficiente ---
            copia = new ArrayList<>(original);
            ini = System.nanoTime();
            Ordenador.mergeSort(copia, Ordenador.porPreco());
            tabela[1][t] = Cronometro.formatar(System.nanoTime() - ini);

            // --- Referência (List.sort da biblioteca) ---
            copia = new ArrayList<>(original);
            ini = System.nanoTime();
            copia.sort(Ordenador.porPreco());
            tabela[2][t] = Cronometro.formatar(System.nanoTime() - ini);

            // --- Buscas: amostra de 100 ids espalhados pela lista ---
            final int n = original.size();
            final int[] ids = new int[100];
            for (int i = 0; i < ids.length; i++) {
                ids[i] = original.get((int) ((i * 7919L) % n)).getId();
            }

            // lista ordenada por id (necessária para a busca binária)
            final List<Produto> porId = new ArrayList<>(original);
            Ordenador.mergeSort(porId, Ordenador.porId());

            tabela[3][t] = Cronometro.formatar(Cronometro.mediaNs(REPETICOES,
                    i -> Buscador.buscaLinear(original, ids[i % ids.length])));

            tabela[4][t] = Cronometro.formatar(Cronometro.mediaNs(REPETICOES,
                    i -> Buscador.buscaBinaria(porId, ids[i % ids.length])));

            final HashMap<Integer, Produto> mapa = Buscador.construirMapaId(original);
            tabela[5][t] = Cronometro.formatar(Cronometro.mediaNs(REPETICOES,
                    i -> Buscador.buscaPorMapa(mapa, ids[i % ids.length])));

            // custo de construir o HashMap (média de 5 construções)
            tabela[6][t] = Cronometro.formatar(Cronometro.mediaNs(5,
                    i -> Buscador.construirMapaId(original)));
        }

        String texto = montarTexto(tabela);
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(caminhoSaida), StandardCharsets.UTF_8)) {
            bw.write(texto);
        }
        return texto;
    }

    /** Monta a tabela alinhada + a análise final (até 5 linhas). */
    private static String montarTexto(String[][] tabela) {
        StringBuilder sb = new StringBuilder();
        sb.append("RELATÓRIO DE TEMPOS - Pesquisa e Ordenação\n\n");
        sb.append(String.format("%-36s %-24s %-24s %-24s%n",
                "Operação", "1.000", "10.000", "50.000"));
        sb.append("-".repeat(111)).append('\n');
        for (int i = 0; i < OPERACOES.length; i++) {
            sb.append(String.format("%-36s %-24s %-24s %-24s%n",
                    OPERACOES[i], tabela[i][0], tabela[i][1], tabela[i][2]));
        }
        sb.append("\nANÁLISE\n");
        sb.append("1) A busca por HashMap foi a mais rápida: acesso O(1) em média, contra O(log n) da binária e O(n) da linear.\n");
        sb.append("2) A binária exige lista ordenada por id; a linear não exige preparo, mas cresce com o tamanho da lista.\n");
        sb.append("3) Vale construir o HashMap (custo O(n), pago uma vez) quando haverá muitas consultas sobre os mesmos dados.\n");
        sb.append("4) Para uma ou poucas buscas, a linear basta: montar o mapa custa mais que varrer a lista uma vez.\n");
        sb.append("5) A binária só compensa se a lista já estiver ordenada ou se o custo de ordenar for diluído em muitas buscas.\n");
        return sb.toString();
    }
}

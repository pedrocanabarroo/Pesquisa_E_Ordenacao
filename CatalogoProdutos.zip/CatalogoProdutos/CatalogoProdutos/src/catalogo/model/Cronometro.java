package catalogo.model;

import java.util.Locale;
import java.util.function.IntFunction;

/** Utilitário de medição de tempo com System.nanoTime(). */
public class Cronometro {

    // Acumula resultados para o compilador/JIT não descartar a operação medida
    private static long sorvedouro;

    /**
     * Executa a operação várias vezes e devolve o tempo MÉDIO em nanossegundos.
     * Faz um aquecimento antes, para o JIT otimizar o código.
     */
    public static double mediaNs(int repeticoes, IntFunction<Object> operacao) {
        int aquecimento = Math.max(1, repeticoes / 10);
        for (int i = 0; i < aquecimento; i++) {
            sorvedouro += System.identityHashCode(operacao.apply(i));
        }
        long inicio = System.nanoTime();
        for (int i = 0; i < repeticoes; i++) {
            sorvedouro += System.identityHashCode(operacao.apply(i));
        }
        long total = System.nanoTime() - inicio;
        return (double) total / repeticoes;
    }

    /** Formata nanossegundos na unidade mais legível (ns, µs, ms ou s). */
    public static String formatar(double ns) {
        Locale br = Locale.forLanguageTag("pt-BR");
        if (ns < 1_000) {
            return String.format(br, "%.0f ns", ns);
        } else if (ns < 1_000_000) {
            return String.format(br, "%.2f µs", ns / 1_000);
        } else if (ns < 1_000_000_000) {
            return String.format(br, "%.2f ms", ns / 1_000_000);
        }
        return String.format(br, "%.2f s", ns / 1_000_000_000);
    }
}

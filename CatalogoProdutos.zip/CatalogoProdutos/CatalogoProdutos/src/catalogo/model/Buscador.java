package catalogo.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/** Técnicas de busca: linear, binária e consulta a HashMap. */
public class Buscador {

    /** Busca linear O(n): percorre a lista até achar o id. */
    public static Produto buscaLinear(List<Produto> lista, int id) {
        for (Produto p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    /**
     * Busca binária O(log n). ATENÇÃO: a lista precisa estar ordenada por id,
     * senão o resultado é incorreto.
     */
    public static Produto buscaBinaria(List<Produto> lista, int id) {
        int ini = 0;
        int fim = lista.size() - 1;
        while (ini <= fim) {
            int meio = (ini + fim) >>> 1;
            int idMeio = lista.get(meio).getId();
            if (idMeio == id) {
                return lista.get(meio);
            } else if (idMeio < id) {
                ini = meio + 1;   // descarta a metade esquerda
            } else {
                fim = meio - 1;   // descarta a metade direita
            }
        }
        return null;
    }

    /** Consulta por id num HashMap: O(1) em média. */
    public static Produto buscaPorMapa(HashMap<Integer, Produto> mapa, int id) {
        return mapa.get(id);
    }

    /** Monta o HashMap id -> Produto (feito uma vez na carga dos dados). */
    public static HashMap<Integer, Produto> construirMapaId(List<Produto> lista) {
        HashMap<Integer, Produto> mapa = new HashMap<>(lista.size() * 2);
        for (Produto p : lista) {
            mapa.put(p.getId(), p);
        }
        return mapa;
    }

    /** Monta o índice categoria (minúscula) -> lista de produtos daquela categoria. */
    public static HashMap<String, List<Produto>> construirIndiceCategoria(List<Produto> lista) {
        HashMap<String, List<Produto>> indice = new HashMap<>();
        for (Produto p : lista) {
            indice.computeIfAbsent(p.getCategoria().toLowerCase(), k -> new ArrayList<>()).add(p);
        }
        return indice;
    }

    /** Lista os produtos de uma categoria usando o índice (chave em minúsculas). */
    public static List<Produto> buscaPorCategoria(HashMap<String, List<Produto>> indice, String chave) {
        List<Produto> r = indice.get(chave);
        return r == null ? Collections.<Produto>emptyList() : r;
    }

    /** Verifica se a lista está em ordem crescente de id (pré-condição da busca binária). */
    public static boolean estaOrdenadoPorId(List<Produto> lista) {
        for (int i = 1; i < lista.size(); i++) {
            if (lista.get(i - 1).getId() > lista.get(i).getId()) {
                return false;
            }
        }
        return true;
    }
}

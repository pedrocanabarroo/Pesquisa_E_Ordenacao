package catalogo.model;

import java.util.List;

/** Resultado de uma busca: produtos encontrados + tempo médio das repetições. */
public class ResultadoBusca {

    private final List<Produto> encontrados;
    private final double tempoMedioNs;

    public ResultadoBusca(List<Produto> encontrados, double tempoMedioNs) {
        this.encontrados = encontrados;
        this.tempoMedioNs = tempoMedioNs;
    }

    public List<Produto> getEncontrados() { return encontrados; }
    public double getTempoMedioNs() { return tempoMedioNs; }
}

package catalogo;

import catalogo.controller.ProdutoController;
import catalogo.view.TelaPrincipal;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Trabalho Prático – Pesquisa e Ordenação (UFN)
 * Professor: Alexandre Zamberlan
 *
 * Autor(es): Pedro Henrique de Brito Canabarro, (demais integrantes, se houver)
 * Turma: ________
 *
 * Classe principal: apenas liga as peças do MVC e abre a tela.
 */
public class Main {

    public static void main(String[] args) {
        // Toda interface Swing deve ser criada na Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            try {
                // Visual nativo do sistema operacional
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignorada) {
                // se falhar, usa o visual padrão do Swing
            }
            ProdutoController controller = new ProdutoController(); // Controller
            TelaPrincipal tela = new TelaPrincipal(controller);     // View
            tela.setVisible(true);
        });
    }
}

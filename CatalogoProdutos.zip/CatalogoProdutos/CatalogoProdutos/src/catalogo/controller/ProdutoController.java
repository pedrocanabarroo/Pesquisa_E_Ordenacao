package catalogo.controller;

import catalogo.model.Buscador;
import catalogo.model.Cronometro;
import catalogo.model.GeradorRelatorio;
import catalogo.model.GerenciadorArquivos;
import catalogo.model.Ordenador;
import catalogo.model.Produto;
import catalogo.model.ResultadoBusca;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.function.IntFunction;

/**
 * Controller: recebe os pedidos da tela, aciona as classes do model
 * e devolve os resultados. Não conhece nenhum componente Swing.
 */
public class ProdutoController {

    // Opções disponíveis (a View usa estas constantes para montar os combos)
    public static final String CAMPO_NOME = "Nome";
    public static final String CAMPO_PRECO = "Preço";
    public static final String CAMPO_ID = "ID";

    public static final String ALG_BUBBLE = "Bubble Sort (simples)";
    public static final String ALG_MERGE = "Merge Sort (eficiente)";
    public static final String ALG_REFERENCIA = "List.sort (referência)";

    public static final String BUSCA_LINEAR = "Busca linear (id)";
    public static final String BUSCA_BINARIA = "Busca binária (id)";
    public static final String BUSCA_HASHMAP = "HashMap (id)";
    public static final String BUSCA_CATEGORIA = "Categoria (HashMap)";

    public static final int REPETICOES = 1000;          // repetições para o tempo médio
    private static final long LIMITE_SIMPLES_MS = 120_000; // 2 minutos

    // Estado atual dos dados
    private List<Produto> produtos = new ArrayList<>();
    private HashMap<Integer, Produto> mapaId = new HashMap<>();
    private HashMap<String, List<Produto>> indiceCategoria = new HashMap<>();
    private long tempoConstrucaoMapaNs;

    // ---------- Arquivos ----------

    /** Lê o arquivo e monta os HashMaps (mapa por id e índice por categoria). */
    public void carregar(String caminho) throws IOException {
        List<Produto> lidos = GerenciadorArquivos.ler(caminho);

        long ini = System.nanoTime();
        HashMap<Integer, Produto> novoMapa = Buscador.construirMapaId(lidos);
        tempoConstrucaoMapaNs = System.nanoTime() - ini;

        indiceCategoria = Buscador.construirIndiceCategoria(lidos);
        mapaId = novoMapa;
        produtos = lidos;
    }

    /** Exporta a lista na ordem em que está agora. */
    public void exportar(String caminho) throws IOException {
        GerenciadorArquivos.exportar(produtos, caminho);
    }

    // ---------- Ordenação ----------

    /**
     * Ordena a lista atual e devolve o tempo em nanossegundos,
     * ou -1 se o algoritmo simples passou de 2 minutos e foi interrompido.
     */
    public long ordenar(String algoritmo, String campo) {
        Comparator<Produto> comparador = escolherComparator(campo);

        long inicio = System.nanoTime();
        switch (algoritmo) {
            case ALG_BUBBLE:
                if (!Ordenador.bubbleSort(produtos, comparador, LIMITE_SIMPLES_MS)) {
                    return -1;
                }
                break;
            case ALG_MERGE:
                Ordenador.mergeSort(produtos, comparador);
                break;
            case ALG_REFERENCIA:
                produtos.sort(comparador);
                break;
            default:
                throw new IllegalArgumentException("Algoritmo desconhecido: " + algoritmo);
        }
        return System.nanoTime() - inicio;
    }

    private Comparator<Produto> escolherComparator(String campo) {
        switch (campo) {
            case CAMPO_NOME:  return Ordenador.porNome();
            case CAMPO_PRECO: return Ordenador.porPreco();
            case CAMPO_ID:    return Ordenador.porId();
            default: throw new IllegalArgumentException("Campo desconhecido: " + campo);
        }
    }

    // ---------- Busca ----------

    /** Busca um produto por id com a técnica escolhida e mede o tempo médio. */
    public ResultadoBusca buscarPorId(String tecnica, int id) {
        final List<Produto> lista = produtos;
        final HashMap<Integer, Produto> mapa = mapaId;
        IntFunction<Object> operacao;

        switch (tecnica) {
            case BUSCA_LINEAR:
                operacao = i -> Buscador.buscaLinear(lista, id);
                break;
            case BUSCA_BINARIA:
                // a busca binária só funciona com a lista ordenada pelo campo buscado
                if (!Buscador.estaOrdenadoPorId(lista)) {
                    throw new IllegalStateException(
                            "A busca binária exige a lista ordenada por ID.\n"
                            + "Ordene primeiro por ID e tente de novo.");
                }
                operacao = i -> Buscador.buscaBinaria(lista, id);
                break;
            case BUSCA_HASHMAP:
                operacao = i -> Buscador.buscaPorMapa(mapa, id);
                break;
            default:
                throw new IllegalArgumentException("Técnica desconhecida: " + tecnica);
        }

        Produto achado = (Produto) operacao.apply(0);
        double media = Cronometro.mediaNs(REPETICOES, operacao);
        List<Produto> resultado = (achado == null)
                ? Collections.<Produto>emptyList()
                : Collections.singletonList(achado);
        return new ResultadoBusca(resultado, media);
    }

    /** Lista os produtos de uma categoria usando o HashMap<String, List<Produto>>. */
    public ResultadoBusca buscarPorCategoria(String categoria) {
        final HashMap<String, List<Produto>> indice = indiceCategoria;
        final String chave = categoria.trim().toLowerCase();

        List<Produto> resultado = Buscador.buscaPorCategoria(indice, chave);
        double media = Cronometro.mediaNs(REPETICOES,
                i -> Buscador.buscaPorCategoria(indice, chave));
        return new ResultadoBusca(resultado, media);
    }

    // ---------- Relatório ----------

    /** Gera o relatorio.txt na pasta do projeto e devolve o texto. */
    public String gerarRelatorio() throws IOException {
        return GeradorRelatorio.gerar("relatorio.txt");
    }

    // ---------- Consultas de estado ----------

    public List<Produto> getProdutos() { return produtos; }
    public boolean temDados() { return !produtos.isEmpty(); }
    public long getTempoConstrucaoMapaNs() { return tempoConstrucaoMapaNs; }
}

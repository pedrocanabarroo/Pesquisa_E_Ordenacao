package catalogo.view;

import catalogo.model.Produto;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/** Adapta uma List<Produto> para a JTable (rápido mesmo com 50.000 linhas). */
public class ProdutoTableModel extends AbstractTableModel {

    private static final String[] COLUNAS = {"ID", "Nome", "Categoria", "Preço (R$)", "Estoque"};
    private List<Produto> dados = new ArrayList<>();

    /** Troca a lista exibida e manda a tabela se redesenhar. */
    public void atualizar(List<Produto> novos) {
        this.dados = novos;
        fireTableDataChanged();
    }

    @Override public int getRowCount() { return dados.size(); }
    @Override public int getColumnCount() { return COLUNAS.length; }
    @Override public String getColumnName(int col) { return COLUNAS[col]; }

    @Override
    public Class<?> getColumnClass(int col) {
        switch (col) {
            case 0: case 4: return Integer.class;
            case 3: return Double.class;
            default: return String.class;
        }
    }

    @Override
    public Object getValueAt(int linha, int col) {
        Produto p = dados.get(linha);
        switch (col) {
            case 0: return p.getId();
            case 1: return p.getNome();
            case 2: return p.getCategoria();
            case 3: return p.getPreco();
            default: return p.getEstoque();
        }
    }
}

package catalogo.view;

import catalogo.controller.ProdutoController;
import catalogo.model.Cronometro;
import catalogo.model.ResultadoBusca;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.io.File;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

/**
 * View: interface Swing. Só monta a tela e repassa os pedidos ao Controller.
 * Operações demoradas rodam em SwingWorker para a janela não congelar.
 */
public class TelaPrincipal extends JFrame {

    private final ProdutoController controller;
    private final ProdutoTableModel modeloTabela = new ProdutoTableModel();
    private final JTable tabela = new JTable(modeloTabela);

    // 1. Arquivo
    private final JComboBox<String> cbArquivo = new JComboBox<>(new String[]{
        "produtos_1000.txt", "produtos_10000.txt", "produtos_50000.txt"});
    private final JButton btnCarregar = new JButton("Carregar");
    private final JButton btnProcurar = new JButton("Procurar...");

    // 2. Ordenação
    private final JComboBox<String> cbCampo = new JComboBox<>(new String[]{
        ProdutoController.CAMPO_NOME, ProdutoController.CAMPO_PRECO, ProdutoController.CAMPO_ID});
    private final JComboBox<String> cbAlgoritmo = new JComboBox<>(new String[]{
        ProdutoController.ALG_BUBBLE, ProdutoController.ALG_MERGE, ProdutoController.ALG_REFERENCIA});
    private final JButton btnOrdenar = new JButton("Ordenar");

    // 3. Busca
    private final JComboBox<String> cbBusca = new JComboBox<>(new String[]{
        ProdutoController.BUSCA_LINEAR, ProdutoController.BUSCA_BINARIA,
        ProdutoController.BUSCA_HASHMAP, ProdutoController.BUSCA_CATEGORIA});
    private final JTextField txtBusca = new JTextField(14);
    private final JButton btnBuscar = new JButton("Buscar");
    private final JButton btnMostrarTodos = new JButton("Mostrar todos");

    // 4. Ações
    private final JButton btnExportar = new JButton("Exportar lista...");
    private final JButton btnRelatorio = new JButton("Gerar relatório.txt");

    // Rodapé
    private final JLabel lblTempo = new JLabel("Tempo da última operação: -");
    private final JLabel lblStatus = new JLabel("Carregue um arquivo para começar.");

    public TelaPrincipal(ProdutoController controller) {
        super("Catálogo de Produtos - Pesquisa e Ordenação");
        this.controller = controller;
        montarTela();
        ligarEventos();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null); // centraliza
    }

    // ---------- Montagem da interface ----------

    private void montarTela() {
        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));
        topo.add(painel("1. Arquivo", new JLabel("Arquivo:"), cbArquivo, btnProcurar, btnCarregar));
        topo.add(painel("2. Ordenação", new JLabel("Campo:"), cbCampo,
                new JLabel("Algoritmo:"), cbAlgoritmo, btnOrdenar));
        topo.add(painel("3. Busca", new JLabel("Técnica:"), cbBusca,
                new JLabel("Id ou categoria:"), txtBusca, btnBuscar, btnMostrarTodos));
        topo.add(painel("4. Ações", btnExportar, btnRelatorio));

        tabela.setFillsViewportHeight(true);

        JPanel rodape = new JPanel(new BorderLayout());
        rodape.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        lblTempo.setFont(lblTempo.getFont().deriveFont(java.awt.Font.BOLD, 14f));
        rodape.add(lblTempo, BorderLayout.NORTH);
        rodape.add(lblStatus, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(topo, BorderLayout.NORTH);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(rodape, BorderLayout.SOUTH);
    }

    /** Cria um painel com título e os componentes alinhados à esquerda. */
    private JPanel painel(String titulo, java.awt.Component... componentes) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setBorder(BorderFactory.createTitledBorder(titulo));
        for (java.awt.Component c : componentes) {
            p.add(c);
        }
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height + 10));
        return p;
    }

    // ---------- Eventos ----------

    private void ligarEventos() {
        btnProcurar.addActionListener(e -> escolherArquivo());
        btnCarregar.addActionListener(e -> carregar());
        btnOrdenar.addActionListener(e -> ordenar());
        btnBuscar.addActionListener(e -> buscar());
        txtBusca.addActionListener(e -> buscar()); // Enter também busca
        btnMostrarTodos.addActionListener(e -> mostrarTodos());
        btnExportar.addActionListener(e -> exportar());
        btnRelatorio.addActionListener(e -> gerarRelatorio());
    }

    private void escolherArquivo() {
        JFileChooser fc = new JFileChooser(new File(System.getProperty("user.dir")));
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            String caminho = fc.getSelectedFile().getPath();
            cbArquivo.addItem(caminho);
            cbArquivo.setSelectedItem(caminho);
        }
    }

    private void carregar() {
        String arquivo = (String) cbArquivo.getSelectedItem();
        executar("Carregando " + arquivo + "...", () -> {
            controller.carregar(arquivo);
            return null;
        }, r -> {
            mostrarTodos();
            lblTempo.setText("Construção do HashMap (id): "
                    + Cronometro.formatar(controller.getTempoConstrucaoMapaNs()));
            lblStatus.setText(controller.getProdutos().size() + " produtos carregados de " + arquivo);
        });
    }

    private void ordenar() {
        if (!verificarDados()) {
            return;
        }
        String algoritmo = (String) cbAlgoritmo.getSelectedItem();
        String campo = (String) cbCampo.getSelectedItem();

        executar("Ordenando por " + campo + " com " + algoritmo + "...",
                () -> controller.ordenar(algoritmo, campo),
                ns -> {
                    mostrarTodos();
                    if (ns < 0) {
                        lblTempo.setText(algoritmo + ": não concluído (> 2 min)");
                    } else {
                        lblTempo.setText(algoritmo + " por " + campo + ": "
                                + Cronometro.formatar(ns));
                    }
                });
    }

    private void buscar() {
        if (!verificarDados()) {
            return;
        }
        String tecnica = (String) cbBusca.getSelectedItem();
        String texto = txtBusca.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Digite um id ou uma categoria.");
            return;
        }

        Callable<ResultadoBusca> tarefa;
        if (tecnica.equals(ProdutoController.BUSCA_CATEGORIA)) {
            tarefa = () -> controller.buscarPorCategoria(texto);
        } else {
            int id;
            try {
                id = Integer.parseInt(texto);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "O id deve ser um número inteiro.");
                return;
            }
            tarefa = () -> controller.buscarPorId(tecnica, id);
        }

        executar("Buscando...", tarefa, r -> {
            modeloTabela.atualizar(r.getEncontrados()); // tabela mostra só o resultado
            lblTempo.setText(tecnica + " - tempo médio de " + ProdutoController.REPETICOES
                    + " repetições: " + Cronometro.formatar(r.getTempoMedioNs()));
            lblStatus.setText(r.getEncontrados().isEmpty()
                    ? "Nenhum produto encontrado."
                    : r.getEncontrados().size() + " produto(s) encontrado(s).");
        });
    }

    /** Volta a tabela a exibir a lista completa (na ordem atual). */
    private void mostrarTodos() {
        modeloTabela.atualizar(controller.getProdutos());
        lblStatus.setText(controller.getProdutos().size() + " produtos na tabela.");
    }

    private void exportar() {
        if (!verificarDados()) {
            return;
        }
        JFileChooser fc = new JFileChooser(new File(System.getProperty("user.dir")));
        fc.setSelectedFile(new File("produtos_exportados.txt"));
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            String caminho = fc.getSelectedFile().getPath();
            executar("Exportando...", () -> {
                controller.exportar(caminho);
                return null;
            }, r -> lblStatus.setText("Lista exportada para " + caminho));
        }
    }

    private void gerarRelatorio() {
        executar("Gerando relatorio.txt (pode levar um tempo)...",
                () -> controller.gerarRelatorio(),
                texto -> {
                    lblStatus.setText("relatorio.txt gerado na pasta do projeto.");
                    JTextArea area = new JTextArea(texto, 22, 100);
                    area.setFont(new java.awt.Font(java.awt.Font.MONOSPACED, java.awt.Font.PLAIN, 12));
                    area.setEditable(false);
                    JOptionPane.showMessageDialog(this, new JScrollPane(area),
                            "Relatório de tempos", JOptionPane.INFORMATION_MESSAGE);
                });
    }

    // ---------- Apoio ----------

    private boolean verificarDados() {
        if (!controller.temDados()) {
            JOptionPane.showMessageDialog(this, "Carregue um arquivo primeiro.");
            return false;
        }
        return true;
    }

    /**
     * Executa a tarefa numa thread de fundo (SwingWorker) e, ao terminar,
     * chama aoConcluir na thread da interface. Erros viram uma caixa de mensagem.
     */
    private <T> void executar(String mensagem, Callable<T> tarefa, Consumer<T> aoConcluir) {
        definirOcupado(true, mensagem);
        new SwingWorker<T, Void>() {
            @Override
            protected T doInBackground() throws Exception {
                return tarefa.call();
            }

            @Override
            protected void done() {
                definirOcupado(false, null);
                try {
                    aoConcluir.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    Throwable causa = ex.getCause();
                    String msg = causa.getMessage() != null ? causa.getMessage() : causa.toString();
                    JOptionPane.showMessageDialog(TelaPrincipal.this, msg,
                            "Atenção", JOptionPane.WARNING_MESSAGE);
                    lblStatus.setText("Operação não concluída.");
                }
            }
        }.execute();
    }

    /** Desabilita os botões enquanto algo está rodando. */
    private void definirOcupado(boolean ocupado, String mensagem) {
        for (JButton b : new JButton[]{btnCarregar, btnProcurar, btnOrdenar, btnBuscar,
            btnMostrarTodos, btnExportar, btnRelatorio}) {
            b.setEnabled(!ocupado);
        }
        setCursor(Cursor.getPredefinedCursor(ocupado ? Cursor.WAIT_CURSOR : Cursor.DEFAULT_CURSOR));
        if (mensagem != null) {
            lblStatus.setText(mensagem);
        }
    }
}

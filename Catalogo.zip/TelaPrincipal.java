package view;

import controller.CatalogoController;
import controller.RelatorioController;
import model.Resultado;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

/** Só monta a tela e chama o controller. Não ordena nem busca nada. */
public class TelaPrincipal extends JFrame {

    private final CatalogoController controller = new CatalogoController();
    private final ProdutoTableModel modelo = new ProdutoTableModel();
    private final JTable tabela = new JTable(modelo);

    private final JComboBox<String> cbArquivo = new JComboBox<>(CatalogoController.ARQUIVOS);
    private final JComboBox<String> cbCampo = new JComboBox<>(CatalogoController.CAMPOS);
    private final JComboBox<String> cbAlgoritmo = new JComboBox<>(CatalogoController.ALGORITMOS);
    private final JComboBox<String> cbTecnica = new JComboBox<>(CatalogoController.TECNICAS);
    private final JTextField txtId = new JTextField(8);
    private final JTextField txtCategoria = new JTextField(12);
    private final JLabel lblTempo = new JLabel("Tempo da última operação: -");
    private final JLabel lblStatus = new JLabel(" ");
    private final List<JButton> botoes = new ArrayList<>();

    public TelaPrincipal() {
        super("Catálogo de Produtos - Pesquisa e Ordenação");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(950, 600);
        setLocationRelativeTo(null);
        montarTela();
    }

    private void montarTela() {
        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.Y_AXIS));

        JPanel l1 = linha();
        l1.add(new JLabel("Arquivo:"));
        l1.add(cbArquivo);
        l1.add(botao("Carregar", this::carregar));
        l1.add(botao("Exportar lista atual", this::exportar));

        JPanel l2 = linha();
        l2.add(new JLabel("Ordenar por:"));
        l2.add(cbCampo);
        l2.add(new JLabel("Algoritmo:"));
        l2.add(cbAlgoritmo);
        l2.add(botao("Ordenar", this::ordenar));

        JPanel l3 = linha();
        l3.add(new JLabel("Busca por id:"));
        l3.add(cbTecnica);
        l3.add(new JLabel("Id:"));
        l3.add(txtId);
        l3.add(botao("Buscar por id", this::buscarPorId));

        JPanel l4 = linha();
        l4.add(new JLabel("Categoria:"));
        l4.add(txtCategoria);
        l4.add(botao("Buscar por categoria", this::buscarPorCategoria));
        l4.add(botao("Mostrar todos", this::mostrarTodos));
        l4.add(botao("Gerar relatório", this::gerarRelatorio));

        topo.add(l1);
        topo.add(l2);
        topo.add(l3);
        topo.add(l4);

        JPanel rodape = new JPanel(new GridLayout(2, 1));
        rodape.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        rodape.add(lblTempo);
        rodape.add(lblStatus);

        add(topo, BorderLayout.NORTH);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(rodape, BorderLayout.SOUTH);
    }

    private JPanel linha() {
        return new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
    }

    private JButton botao(String texto, Runnable acao) {
        JButton b = new JButton(texto);
        b.addActionListener(e -> acao.run());
        botoes.add(b);
        return b;
    }

    // ---------- Ações dos botões ----------

    private void carregar() {
        String arquivo = (String) cbArquivo.getSelectedItem();
        executar("Carregando " + arquivo + "...",
                () -> controller.carregar(CatalogoController.PASTA_DADOS + File.separator + arquivo));
    }

    private void ordenar() {
        String campo = (String) cbCampo.getSelectedItem();
        String algoritmo = (String) cbAlgoritmo.getSelectedItem();
        executar("Ordenando...", () -> {
            Resultado r = controller.ordenar(campo, algoritmo);
            return r;
        });
    }

    private void buscarPorId() {
        int id;
        try {
            id = Integer.parseInt(txtId.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um id numérico.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String tecnica = (String) cbTecnica.getSelectedItem();
        executar("Buscando...", () -> controller.buscarPorId(id, tecnica));
    }

    private void buscarPorCategoria() {
        String categoria = txtCategoria.getText();
        if (categoria.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe uma categoria.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        executar("Buscando...", () -> controller.buscarPorCategoria(categoria));
    }

    private void mostrarTodos() {
        executar("Carregando lista...",
                () -> new Resultado("Lista completa", -1, controller.getProdutosAtuais()));
    }

    private void exportar() {
        JFileChooser fc = new JFileChooser(new File("."));
        fc.setSelectedFile(new File("exportado.txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        String caminho = fc.getSelectedFile().getPath();
        executar("Exportando...", () -> {
            controller.exportar(caminho);
            return Resultado.mensagem("Arquivo exportado em " + caminho);
        });
    }

    private void gerarRelatorio() {
        executar("Gerando relatório (pode demorar)...", () -> {
            new RelatorioController().gerar(CatalogoController.PASTA_DADOS, "relatorio.txt");
            return Resultado.mensagem("Relatório gerado em relatorio.txt");
        });
    }

    // ---------- Execução em segundo plano (a tela não trava) ----------

    private void executar(String status, Callable<Resultado> tarefa) {
        lblStatus.setText(status);
        setBotoes(false);
        new SwingWorker<Resultado, Void>() {
            @Override
            protected Resultado doInBackground() throws Exception {
                return tarefa.call();
            }

            @Override
            protected void done() {
                try {
                    Resultado r = get();
                    if (r.getProdutos() != null) {
                        modelo.setProdutos(r.getProdutos());
                        lblStatus.setText(r.getProdutos().size() + " registro(s) exibido(s)");
                    } else {
                        lblStatus.setText(" ");
                    }
                    lblTempo.setText("Tempo da última operação: " + r.getResumo());
                } catch (Exception e) {
                    Throwable causa = e.getCause() != null ? e.getCause() : e;
                    lblStatus.setText(" ");
                    JOptionPane.showMessageDialog(TelaPrincipal.this, causa.getMessage(),
                            "Erro", JOptionPane.ERROR_MESSAGE);
                } finally {
                    setBotoes(true);
                }
            }
        }.execute();
    }

    private void setBotoes(boolean habilitado) {
        for (JButton b : botoes) {
            b.setEnabled(habilitado);
        }
    }
}

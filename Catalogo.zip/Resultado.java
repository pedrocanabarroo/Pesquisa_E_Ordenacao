package model;

import java.util.List;

/** Resultado de uma operação: descrição, tempo e (opcionalmente) a lista a exibir. */
public class Resultado {
    private final String descricao;
    private final double tempoNs;      // negativo = sem tempo
    private final boolean concluido;
    private final List<Produto> produtos;

    public Resultado(String descricao, double tempoNs, List<Produto> produtos) {
        this.descricao = descricao;
        this.tempoNs = tempoNs;
        this.concluido = true;
        this.produtos = produtos;
    }

    private Resultado(String descricao) {
        this.descricao = descricao;
        this.tempoNs = -1;
        this.concluido = false;
        this.produtos = null;
    }

    public static Resultado naoConcluido(String descricao) {
        return new Resultado(descricao);
    }

    public static Resultado mensagem(String texto) {
        return new Resultado(texto, -1, null);
    }

    public String getDescricao() { return descricao; }
    public double getTempoNs() { return tempoNs; }
    public boolean isConcluido() { return concluido; }
    public List<Produto> getProdutos() { return produtos; }

    public String getTempoFormatado() {
        return concluido ? Tempo.formatar(tempoNs) : "não concluído (> 2 min)";
    }

    public String getResumo() {
        if (concluido && tempoNs < 0) return descricao;
        return descricao + ": " + getTempoFormatado();
    }
}

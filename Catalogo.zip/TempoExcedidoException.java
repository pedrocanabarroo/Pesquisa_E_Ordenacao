package model;

/** Lançada quando uma ordenação passa do limite de tempo. */
public class TempoExcedidoException extends RuntimeException {
    public TempoExcedidoException() {
        super("Tempo limite excedido");
    }
}

package view;

import model.Produto;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Liga a List<Produto> à JTable. */
public class ProdutoTableModel extends AbstractTableModel {
    private static final String[] COLUNAS = {"ID", "Nome", "Categoria", "Preço", "Estoque"};
    private List<Produto> produtos = new ArrayList<>();

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
        fireTableDataChanged();
    }

    @Override public int getRowCount() { return produtos.size(); }
    @Override public int getColumnCount() { return COLUNAS.length; }
    @Override public String getColumnName(int col) { return COLUNAS[col]; }

    @Override
    public Object getValueAt(int linha, int col) {
        Produto p = produtos.get(linha);
        switch (col) {
            case 0: return p.getId();
            case 1: return p.getNome();
            case 2: return p.getCategoria();
            case 3: return String.format(Locale.forLanguageTag("pt-BR"), "%.2f", p.getPreco());
            default: return p.getEstoque();
        }
    }
}

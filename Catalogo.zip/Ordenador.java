package model;

import java.util.Comparator;
import java.util.List;

public class Ordenador {

    public static final long SEM_LIMITE = Long.MAX_VALUE;

    // ---------- Insertion Sort (simples, O(n²)) ----------

    public static void insertionSort(List<Produto> lista, Comparator<Produto> cmp) {
        insertionSort(lista, cmp, SEM_LIMITE);
    }

    /** Lança TempoExcedidoException se passar de limiteNs nanossegundos. */
    public static void insertionSort(List<Produto> lista, Comparator<Produto> cmp, long limiteNs) {
        long inicio = System.nanoTime();
        int n = lista.size();
        for (int i = 1; i < n; i++) {
            Produto chave = lista.get(i);
            int j = i - 1;
            while (j >= 0 && cmp.compare(lista.get(j), chave) > 0) {
                lista.set(j + 1, lista.get(j));
                j--;
            }
            lista.set(j + 1, chave);

            if ((i & 255) == 0 && System.nanoTime() - inicio > limiteNs) {
                throw new TempoExcedidoException();
            }
        }
    }

    // ---------- Merge Sort (eficiente, O(n log n)) ----------

    public static void mergeSort(List<Produto> lista, Comparator<Produto> cmp) {
        if (lista.size() < 2) return;
        Produto[] v = lista.toArray(new Produto[0]);
        Produto[] aux = new Produto[v.length];
        mergeSort(v, aux, 0, v.length - 1, cmp);
        for (int i = 0; i < v.length; i++) {
            lista.set(i, v[i]);
        }
    }

    private static void mergeSort(Produto[] v, Produto[] aux, int ini, int fim, Comparator<Produto> cmp) {
        if (ini >= fim) return;
        int meio = (ini + fim) >>> 1;
        mergeSort(v, aux, ini, meio, cmp);
        mergeSort(v, aux, meio + 1, fim, cmp);
        merge(v, aux, ini, meio, fim, cmp);
    }

    private static void merge(Produto[] v, Produto[] aux, int ini, int meio, int fim, Comparator<Produto> cmp) {
        for (int k = ini; k <= fim; k++) {
            aux[k] = v[k];
        }
        int i = ini;
        int j = meio + 1;
        for (int k = ini; k <= fim; k++) {
            if (i > meio) {
                v[k] = aux[j++];
            } else if (j > fim) {
                v[k] = aux[i++];
            } else if (cmp.compare(aux[j], aux[i]) < 0) {
                v[k] = aux[j++];
            } else {
                v[k] = aux[i++];
            }
        }
    }
}

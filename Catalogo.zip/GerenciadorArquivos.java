package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class GerenciadorArquivos {

    /** Lê o arquivo (UTF-8), ignorando a primeira linha (cabeçalho). */
    public static List<Produto> ler(String caminho) throws IOException {
        List<Produto> lista = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(caminho), StandardCharsets.UTF_8)) {
            String linha = br.readLine(); // cabeçalho
            while ((linha = br.readLine()) != null) {
                if (linha.trim().isEmpty()) continue;
                String[] c = linha.split(";");
                try {
                    lista.add(new Produto(
                            Integer.parseInt(c[0].trim()),
                            c[1].trim(),
                            c[2].trim(),
                            Double.parseDouble(c[3].trim()),
                            Integer.parseInt(c[4].trim())));
                } catch (RuntimeException e) {
                    throw new IOException("Linha inválida: " + linha, e);
                }
            }
        }
        return lista;
    }

    /** Grava a lista, na ordem atual, no mesmo formato do arquivo de entrada. */
    public static void exportar(List<Produto> lista, String caminho) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(caminho), StandardCharsets.UTF_8)) {
            bw.write("id;nome;categoria;preco;estoque");
            bw.newLine();
            for (Produto p : lista) {
                bw.write(p.toLinha());
                bw.newLine();
            }
        }
    }
}

package model;

import java.util.Locale;

public class Tempo {
    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    /** Converte nanossegundos para um texto legível (ns, µs, ms ou s). */
    public static String formatar(double ns) {
        if (ns < 1_000) return String.format(BR, "%.0f ns", ns);
        if (ns < 1_000_000) return String.format(BR, "%.2f µs", ns / 1_000.0);
        if (ns < 1_000_000_000) return String.format(BR, "%.3f ms", ns / 1_000_000.0);
        return String.format(BR, "%.3f s", ns / 1_000_000_000.0);
    }
}

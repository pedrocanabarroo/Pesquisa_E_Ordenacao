package controller;

import model.Comparadores;
import model.Resultado;
import model.Tempo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/** Gera o relatorio.txt. Não usa nada de Swing: roda até sem interface. */
public class RelatorioController {

    private static final int[] TAMANHOS = {1000, 10000, 50000};

    private static final String[] OPERACOES = {
            "Ordenação simples (por preço)",
            "Ordenação eficiente (por preço)",
            "Busca linear por id (média)",
            "Busca binária por id (média)",
            "Busca por HashMap (média)",
            "Construção do HashMap"
    };

    public void gerar(String pastaDados, String arquivoSaida) throws IOException {
        String[][] t = new String[OPERACOES.length][TAMANHOS.length];

        for (int c = 0; c < TAMANHOS.length; c++) {
            String caminho = pastaDados + File.separator + "produtos_" + TAMANHOS[c] + ".txt";
            System.out.println("Medindo " + caminho + " ...");

            CatalogoController ctrl = new CatalogoController();
            Resultado carga = ctrl.carregar(caminho);

            Resultado simples = ctrl.medirOrdenacao(Comparadores.POR_PRECO, true);
            Resultado eficiente = ctrl.medirOrdenacao(Comparadores.POR_PRECO, false);

            int[] ids = ctrl.sortearIds(CatalogoController.REPETICOES, 42);
            double linear = ctrl.medirBuscaMedia(CatalogoController.LINEAR, ids);
            double binaria = ctrl.medirBuscaMedia(CatalogoController.BINARIA, ids);
            double hash = ctrl.medirBuscaMedia(CatalogoController.HASHMAP, ids);

            t[0][c] = simples.getTempoFormatado();
            t[1][c] = eficiente.getTempoFormatado();
            t[2][c] = Tempo.formatar(linear);
            t[3][c] = Tempo.formatar(binaria);
            t[4][c] = Tempo.formatar(hash);
            t[5][c] = Tempo.formatar(carga.getTempoNs());
        }

        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(arquivoSaida), StandardCharsets.UTF_8)) {
            bw.write("RELATÓRIO DE TEMPOS - Pesquisa e Ordenação");
            bw.newLine();
            bw.newLine();
            bw.write(String.format("%-34s | %-14s | %-14s | %-14s", "Operação", "1.000", "10.000", "50.000"));
            bw.newLine();
            bw.write("-".repeat(34) + "-+-" + "-".repeat(14) + "-+-" + "-".repeat(14) + "-+-" + "-".repeat(14));
            bw.newLine();
            for (int i = 0; i < OPERACOES.length; i++) {
                bw.write(String.format("%-34s | %-14s | %-14s | %-14s", OPERACOES[i], t[i][0], t[i][1], t[i][2]));
                bw.newLine();
            }
            bw.newLine();
            bw.write("ANÁLISE");
            bw.newLine();
            bw.write("1) A busca por HashMap foi a mais rápida: o tempo quase não cresce com o tamanho (O(1) em média).");
            bw.newLine();
            bw.write("2) A busca binária (O(log n)) vem em seguida, mas exige a lista ordenada por id.");
            bw.newLine();
            bw.write("3) A busca linear (O(n)) piora conforme a lista cresce, pois percorre os registros um a um.");
            bw.newLine();
            bw.write("4) Vale construir o HashMap quando há muitas consultas sobre os mesmos dados: o custo O(n) é pago uma vez só.");
            bw.newLine();
            bw.write("5) Para uma única consulta, a busca linear basta; o HashMap também gasta memória extra.");
            bw.newLine();
        }
    }
}

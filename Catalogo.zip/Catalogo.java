package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Estado do programa: a lista de produtos e os índices (HashMaps). */
public class Catalogo {
    private List<Produto> original = new ArrayList<>();   // como veio do arquivo (desordenada)
    private List<Produto> atual = new ArrayList<>();      // o que a tabela está mostrando
    private List<Produto> listaPorId;                     // cópia ordenada por id (para busca binária)
    private Map<Integer, Produto> indicePorId = new HashMap<>();
    private Map<String, List<Produto>> indicePorCategoria = new HashMap<>();
    private long tempoConstrucaoNs;

    public void carregar(List<Produto> lista) {
        this.original = lista;
        this.atual = new ArrayList<>(lista);
        this.listaPorId = null;
        reconstruirIndices();
    }

    /** Monta os dois HashMaps e guarda o tempo gasto. */
    public void reconstruirIndices() {
        long inicio = System.nanoTime();
        Map<Integer, Produto> porId = new HashMap<>();
        Map<String, List<Produto>> porCategoria = new HashMap<>();
        for (Produto p : original) {
            porId.put(p.getId(), p);
            porCategoria.computeIfAbsent(p.getCategoria(), k -> new ArrayList<>()).add(p);
        }
        this.indicePorId = porId;
        this.indicePorCategoria = porCategoria;
        this.tempoConstrucaoNs = System.nanoTime() - inicio;
    }

    /** Cria (uma vez) a cópia ordenada por id usada na busca binária. */
    public List<Produto> getListaOrdenadaPorId() {
        if (listaPorId == null) {
            listaPorId = new ArrayList<>(original);
            Ordenador.mergeSort(listaPorId, Comparadores.POR_ID);
        }
        return listaPorId;
    }

    public List<Produto> getCopiaOriginal() { return new ArrayList<>(original); }
    public List<Produto> getOriginal() { return original; }
    public List<Produto> getAtual() { return atual; }
    public void setAtual(List<Produto> atual) { this.atual = atual; }
    public Map<Integer, Produto> getIndicePorId() { return indicePorId; }
    public Map<String, List<Produto>> getIndicePorCategoria() { return indicePorCategoria; }
    public long getTempoConstrucaoNs() { return tempoConstrucaoNs; }
    public boolean isVazio() { return original.isEmpty(); }
}

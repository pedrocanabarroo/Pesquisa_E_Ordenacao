package model;

import java.util.List;
import java.util.Map;

public class Buscador {

    /** Percorre a lista do início ao fim. O(n). */
    public static Produto buscaLinear(List<Produto> lista, int id) {
        for (Produto p : lista) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    /** A lista PRECISA estar ordenada por id. O(log n). */
    public static Produto buscaBinaria(List<Produto> listaOrdenadaPorId, int id) {
        int inicio = 0;
        int fim = listaOrdenadaPorId.size() - 1;
        while (inicio <= fim) {
            int meio = (inicio + fim) >>> 1;
            Produto p = listaOrdenadaPorId.get(meio);
            if (p.getId() == id) return p;
            if (p.getId() < id) inicio = meio + 1;
            else fim = meio - 1;
        }
        return null;
    }

    /** Consulta direta no mapa. O(1) em média. */
    public static Produto buscaHash(Map<Integer, Produto> indicePorId, int id) {
        return indicePorId.get(id);
    }
}

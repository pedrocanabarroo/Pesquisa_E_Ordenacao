/*
 * Trabalho Prático - Pesquisa e Ordenação (UFN)
 * Autor: Pedro Henrique de Brito Canabarro
 * Turma: ______
 *
 * Uso:
 *   sem argumentos  -> abre a interface Swing
 *   --relatorio     -> gera o relatorio.txt direto, sem abrir tela
 */
import controller.CatalogoController;
import controller.RelatorioController;
import view.TelaPrincipal;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("--relatorio")) {
            new RelatorioController().gerar(CatalogoController.PASTA_DADOS, "relatorio.txt");
            System.out.println("relatorio.txt gerado.");
        } else {
            SwingUtilities.invokeLater(() -> new TelaPrincipal().setVisible(true));
        }
    }
}

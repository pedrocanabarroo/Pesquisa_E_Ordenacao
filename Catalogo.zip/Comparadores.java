package model;

import java.util.Comparator;

public class Comparadores {
    public static final Comparator<Produto> POR_ID =
            (a, b) -> Integer.compare(a.getId(), b.getId());

    public static final Comparator<Produto> POR_NOME =
            (a, b) -> a.getNome().compareToIgnoreCase(b.getNome());

    public static final Comparator<Produto> POR_PRECO =
            (a, b) -> Double.compare(a.getPreco(), b.getPreco());
}

package view;

import controller.CatalogoController;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;

/**
 * Janela principal: menu + abas. Só monta e conecta os painéis (View).
 */
public class TelaPrincipal extends JFrame {

    private final CatalogoController controller = new CatalogoController();
    private final JTabbedPane abas = new JTabbedPane();
    private final PainelCatalogo painelCatalogo = new PainelCatalogo(controller);

    public TelaPrincipal() {
        super("Catálogo de Produtos - Pesquisa e Ordenação");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1100, 760);
        setLocationRelativeTo(null);

        abas.addTab("Catálogo", painelCatalogo);
        abas.addTab("Desempenho", new PainelDesempenho());
        abas.addTab("Demonstração", new PainelDemonstracao());
        abas.addTab("Estrutura MVC", new PainelEstrutura());

        setJMenuBar(criarMenu());
        add(abas, BorderLayout.CENTER);

        // Carrega o arquivo pequeno logo que a janela abre, para já mostrar dados na tabela
        SwingUtilities.invokeLater(painelCatalogo::carregarInicial);
    }

    private JMenuBar criarMenu() {
        JMenuBar barra = new JMenuBar();

        JMenu arquivo = new JMenu("Arquivo");
        arquivo.setMnemonic(KeyEvent.VK_A);
        arquivo.add(item("Carregar arquivo selecionado", () -> { abas.setSelectedIndex(0); painelCatalogo.carregar(); }));
        arquivo.add(item("Exportar lista atual...", () -> { abas.setSelectedIndex(0); painelCatalogo.exportar(); }));
        arquivo.addSeparator();
        arquivo.add(item("Sair", () -> System.exit(0)));

        JMenu ferramentas = new JMenu("Ferramentas");
        ferramentas.setMnemonic(KeyEvent.VK_F);
        ferramentas.add(item("Medição de desempenho", () -> abas.setSelectedIndex(1)));
        ferramentas.add(item("Demonstração automática", () -> abas.setSelectedIndex(2)));

        JMenu ajuda = new JMenu("Ajuda");
        ajuda.setMnemonic(KeyEvent.VK_J);
        ajuda.add(item("Estrutura MVC", () -> abas.setSelectedIndex(3)));
        ajuda.add(item("Sobre", this::sobre));

        barra.add(arquivo);
        barra.add(ferramentas);
        barra.add(ajuda);
        return barra;
    }

    private JMenuItem item(String texto, Runnable acao) {
        JMenuItem i = new JMenuItem(texto);
        i.addActionListener(e -> acao.run());
        return i;
    }

    private void sobre() {
        JOptionPane.showMessageDialog(this,
                "Trabalho Prático - Pesquisa e Ordenação (UFN)\n"
                        + "Catálogo de produtos: comparando ordenação e busca.\n\n"
                        + "Java + Swing, arquivos texto e HashMap, em arquitetura MVC.",
                "Sobre", JOptionPane.INFORMATION_MESSAGE);
    }
}

package controller;

import model.Comparadores;
import model.DadosRelatorio;
import model.Resultado;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Consumer;

/**
 * Mede os tempos para 1.000, 10.000 e 50.000 registros e grava o relatorio.txt.
 * Não usa Swing: roda com ou sem interface (java Main --relatorio).
 */
public class RelatorioController {

    public static final int[] TAMANHOS = {1000, 10000, 50000};

    /** Resposta pedida pelo enunciado (até 5 linhas). Confira com os números da sua máquina. */
    public static final String[] ANALISE = {
            "1) A busca por HashMap foi a mais rápida: o tempo quase não cresce com o tamanho (O(1) em média).",
            "2) A busca binária (O(log n)) vem em seguida, mas exige a lista ordenada por id.",
            "3) A busca linear (O(n)) piora conforme a lista cresce, pois percorre os registros um a um.",
            "4) Vale construir o HashMap quando há muitas consultas sobre os mesmos dados: o custo O(n) é pago uma vez só.",
            "5) Para uma única consulta, a busca linear basta; o HashMap também gasta memória extra."
    };

    /** Mede tudo. O "progresso" recebe mensagens de andamento (para a tela ou o console). */
    public DadosRelatorio medir(String pastaDados, Consumer<String> progresso) throws IOException {
        DadosRelatorio dados = new DadosRelatorio(TAMANHOS);

        // Aquecimento: a JVM compila o código "quente" durante a execução (JIT). Sem isto, a
        // primeira medição (1.000 registros) sairia inflada e enganosa. Estes tempos são descartados.
        progresso.accept("Aquecendo a JVM...");
        CatalogoController aquecimento = new CatalogoController();
        aquecimento.carregar(caminho(pastaDados, TAMANHOS[0]));
        for (int i = 0; i < 5; i++) {
            aquecimento.medirOrdenacao(Comparadores.POR_PRECO, true);
            aquecimento.medirOrdenacao(Comparadores.POR_PRECO, false);
        }

        for (int c = 0; c < TAMANHOS.length; c++) {
            progresso.accept("Medindo " + dados.getRotuloTamanho(c) + " registros...");

            CatalogoController ctrl = new CatalogoController();
            Resultado carga = ctrl.carregar(caminho(pastaDados, TAMANHOS[c]));

            // Cada ordenação roda sobre uma cópia da lista original (ver CatalogoController)
            Resultado simples = ctrl.medirOrdenacao(Comparadores.POR_PRECO, true);
            Resultado eficiente = ctrl.medirOrdenacao(Comparadores.POR_PRECO, false);

            // Mesmos 1.000 ids sorteados (semente fixa) para as 3 técnicas: comparação justa
            int[] ids = ctrl.sortearIds(CatalogoController.REPETICOES, 42);

            dados.definir(DadosRelatorio.ORD_SIMPLES, c,
                    simples.isConcluido() ? simples.getTempoNs() : DadosRelatorio.NAO_CONCLUIDO);
            dados.definir(DadosRelatorio.ORD_EFICIENTE, c,
                    eficiente.isConcluido() ? eficiente.getTempoNs() : DadosRelatorio.NAO_CONCLUIDO);
            dados.definir(DadosRelatorio.BUSCA_LINEAR, c, ctrl.medirBuscaMedia(CatalogoController.LINEAR, ids));
            dados.definir(DadosRelatorio.BUSCA_BINARIA, c, ctrl.medirBuscaMedia(CatalogoController.BINARIA, ids));
            dados.definir(DadosRelatorio.BUSCA_HASH, c, ctrl.medirBuscaMedia(CatalogoController.HASHMAP, ids));
            dados.definir(DadosRelatorio.CONSTRUCAO_HASH, c, carga.getTempoNs());
        }
        progresso.accept("Medição concluída.");
        return dados;
    }

    /** Grava a tabela do enunciado + a análise em um arquivo texto (UTF-8). */
    public void salvar(DadosRelatorio dados, String arquivoSaida) throws IOException {
        String formato = "%-34s | %-22s | %-22s | %-22s";
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(arquivoSaida), StandardCharsets.UTF_8)) {
            bw.write("RELATÓRIO DE TEMPOS - Pesquisa e Ordenação");
            bw.newLine();
            bw.newLine();
            bw.write(String.format(formato, "Operação",
                    dados.getRotuloTamanho(0), dados.getRotuloTamanho(1), dados.getRotuloTamanho(2)));
            bw.newLine();
            bw.write(tracos(34) + "-+-" + tracos(22) + "-+-" + tracos(22) + "-+-" + tracos(22));
            bw.newLine();
            for (int i = 0; i < dados.getNumOperacoes(); i++) {
                bw.write(String.format(formato, DadosRelatorio.OPERACOES[i],
                        dados.formatar(i, 0), dados.formatar(i, 1), dados.formatar(i, 2)));
                bw.newLine();
            }
            bw.newLine();
            bw.write("ANÁLISE");
            bw.newLine();
            for (String linha : ANALISE) {
                bw.write(linha);
                bw.newLine();
            }
        }
    }

    /** Mede e grava de uma vez (usado por Main --relatorio e pela demonstração). */
    public void gerar(String pastaDados, String arquivoSaida) throws IOException {
        DadosRelatorio dados = medir(pastaDados, System.out::println);
        salvar(dados, arquivoSaida);
    }

    private String caminho(String pasta, int tamanho) {
        return pasta + File.separator + "produtos_" + tamanho + ".txt";
    }

    private String tracos(int n) {
        return new String(new char[n]).replace('\0', '-');
    }
}

package view;

import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import java.awt.Component;
import java.nio.file.NoSuchFileException;
import java.util.concurrent.Callable;
import java.util.function.Consumer;

/**
 * Utilitário da View: roda uma tarefa pesada FORA da thread da tela (SwingWorker),
 * para a janela não congelar, e devolve o resultado na thread da tela.
 */
public final class Tarefas {

    private Tarefas() { }

    public static <T> void executar(Component pai, Callable<T> tarefa,
                                    Consumer<T> aoConcluir, Runnable aoTerminar) {
        new SwingWorker<T, Void>() {
            @Override
            protected T doInBackground() throws Exception {
                return tarefa.call();              // thread de segundo plano
            }

            @Override
            protected void done() {                // thread da tela (EDT)
                try {
                    aoConcluir.accept(get());
                } catch (Exception e) {
                    erro(pai, e);
                } finally {
                    if (aoTerminar != null) aoTerminar.run();
                }
            }
        }.execute();
    }

    public static void erro(Component pai, Throwable e) {
        JOptionPane.showMessageDialog(pai, mensagem(e), "Erro", JOptionPane.ERROR_MESSAGE);
    }

    /** Traduz exceções técnicas em uma mensagem que o usuário entende. */
    public static String mensagem(Throwable e) {
        Throwable causa = e.getCause() != null ? e.getCause() : e;
        if (causa instanceof NoSuchFileException) {
            return "Arquivo não encontrado: " + causa.getMessage()
                    + "\nColoque os arquivos produtos_*.txt na pasta do projeto.";
        }
        return causa.getMessage() != null ? causa.getMessage() : causa.toString();
    }
}

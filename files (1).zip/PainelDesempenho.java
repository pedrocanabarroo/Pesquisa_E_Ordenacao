package view;

import controller.CatalogoController;
import controller.RelatorioController;
import model.DadosRelatorio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * Aba de desempenho: roda a medição completa (item 3.5 do enunciado), mostra a tabela,
 * um gráfico comparativo e a análise, e grava o relatorio.txt.
 */
public class PainelDesempenho extends JPanel {

    private final RelatorioController relatorio = new RelatorioController();
    private final GraficoBarras grafico = new GraficoBarras();
    private final DefaultTableModel modeloTabela = new DefaultTableModel() {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTextArea txtAnalise = new JTextArea();
    private final JButton btnMedir = new JButton("▶ Medir e gerar relatorio.txt");
    private final JProgressBar barra = new JProgressBar();
    private final JLabel lblStatus = new JLabel(
            "Roda 1.000, 10.000 e 50.000 registros. O Insertion Sort com 50.000 pode levar alguns segundos.");

    public PainelDesempenho() {
        setLayout(new BorderLayout(0, 6));

        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        barra.setPreferredSize(new Dimension(160, 14));
        topo.add(btnMedir);
        topo.add(barra);
        topo.add(lblStatus);
        btnMedir.addActionListener(e -> medir());

        JTable tabela = new JTable(modeloTabela);
        tabela.setRowHeight(22);
        txtAnalise.setEditable(false);
        txtAnalise.setLineWrap(true);
        txtAnalise.setWrapStyleWord(true);
        txtAnalise.setText("A análise (até 5 linhas, como pede o enunciado) aparece aqui após a medição.");

        JScrollPane painelTabela = new JScrollPane(tabela);
        painelTabela.setBorder(BorderFactory.createTitledBorder("Tabela de tempos"));
        JScrollPane painelAnalise = new JScrollPane(txtAnalise);
        painelAnalise.setBorder(BorderFactory.createTitledBorder("Análise"));

        JPanel base = new JPanel(new GridLayout(1, 2, 8, 0));
        base.add(painelTabela);
        base.add(painelAnalise);

        JSplitPane divisor = new JSplitPane(JSplitPane.VERTICAL_SPLIT, grafico, base);
        divisor.setResizeWeight(0.6);

        add(topo, BorderLayout.NORTH);
        add(divisor, BorderLayout.CENTER);
    }

    private void medir() {
        btnMedir.setEnabled(false);
        barra.setIndeterminate(true);

        new SwingWorker<DadosRelatorio, String>() {
            @Override
            protected DadosRelatorio doInBackground() throws Exception {
                DadosRelatorio d = relatorio.medir(CatalogoController.PASTA_DADOS, texto -> publish(texto));
                relatorio.salvar(d, "relatorio.txt"); // o enunciado pede o arquivo gerado automaticamente
                return d;
            }

            @Override
            protected void process(List<String> mensagens) {
                lblStatus.setText(mensagens.get(mensagens.size() - 1));
            }

            @Override
            protected void done() {
                barra.setIndeterminate(false);
                btnMedir.setEnabled(true);
                try {
                    mostrar(get());
                    lblStatus.setText("Concluído. relatorio.txt gerado na pasta do projeto.");
                } catch (Exception e) {
                    lblStatus.setText(" ");
                    Tarefas.erro(PainelDesempenho.this, e);
                }
            }
        }.execute();
    }

    private void mostrar(DadosRelatorio d) {
        int colunas = d.getTamanhos().length;
        String[] cabecalho = new String[colunas + 1];
        cabecalho[0] = "Operação";
        for (int c = 0; c < colunas; c++) cabecalho[c + 1] = d.getRotuloTamanho(c);
        modeloTabela.setColumnIdentifiers(cabecalho);
        modeloTabela.setRowCount(0);
        for (int i = 0; i < d.getNumOperacoes(); i++) {
            Object[] linha = new Object[colunas + 1];
            linha[0] = DadosRelatorio.OPERACOES[i];
            for (int c = 0; c < colunas; c++) linha[c + 1] = d.formatar(i, c);
            modeloTabela.addRow(linha);
        }
        grafico.setDados(d);
        txtAnalise.setText(String.join("\n", RelatorioController.ANALISE));
        txtAnalise.setCaretPosition(0);
    }
}

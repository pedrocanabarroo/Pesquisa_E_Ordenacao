/*
 * Trabalho Prático - Pesquisa e Ordenação (UFN)
 * Autor: Pedro Henrique de Brito Canabarro
 * Turma: ______
 *
 * Uso:
 *   sem argumentos  -> abre a interface Swing
 *   --relatorio     -> gera o relatorio.txt direto, sem abrir tela
 *   --demo          -> roda a demonstração completa no console
 */
import controller.CatalogoController;
import controller.DemonstracaoController;
import controller.RelatorioController;
import view.TelaPrincipal;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("--relatorio")) {
            new RelatorioController().gerar(CatalogoController.PASTA_DADOS, "relatorio.txt");
            System.out.println("relatorio.txt gerado.");
        } else if (args.length > 0 && args[0].equals("--demo")) {
            // Demonstração no console (sem Swing): útil para provar que Model/Controller são independentes da tela
            new DemonstracaoController(System.out::println, lista -> { }).executar();
        } else {
            // Aparência nativa do sistema (Windows, macOS...); se falhar, fica a padrão do Swing
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignorada) {
                // sem problema: usa o visual padrão
            }
            SwingUtilities.invokeLater(() -> new TelaPrincipal().setVisible(true));
        }
    }
}

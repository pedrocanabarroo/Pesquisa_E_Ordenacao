package view;

import model.DadosRelatorio;
import model.Tempo;

import javax.swing.JPanel;
import java.awt.*;

/**
 * Gráfico de barras agrupadas desenhado com Java2D (sem bibliotecas externas).
 * Escala LOGARÍTMICA no eixo vertical: os tempos vão de nanossegundos a segundos
 * (10 ordens de grandeza) e numa escala linear só a barra maior apareceria.
 */
public class GraficoBarras extends JPanel {

    private static final Color[] CORES = {
            new Color(0x4C78A8), new Color(0xF58518), new Color(0x54A24B)
    };

    private DadosRelatorio dados;

    public GraficoBarras() {
        setPreferredSize(new Dimension(900, 330));
        setMinimumSize(new Dimension(300, 200));
    }

    public void setDados(DadosRelatorio dados) {
        this.dados = dados;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        g2.setColor(getForeground());

        if (dados == null) {
            String msg = "O gráfico aparece aqui depois da medição.";
            g2.drawString(msg, (w - g2.getFontMetrics().stringWidth(msg)) / 2, h / 2);
            g2.dispose();
            return;
        }

        // Área do gráfico (margens para eixo, título e rótulos)
        int x0 = 75, y0 = 48, pw = w - x0 - 20, ph = h - y0 - 38;
        int nOps = dados.getNumOperacoes();
        int nCols = dados.getTamanhos().length;

        // Escala: expoente máximo = potência de 10 acima do maior tempo
        double max = 1;
        for (int i = 0; i < nOps; i++) {
            for (int j = 0; j < nCols; j++) max = Math.max(max, dados.getTempo(i, j));
        }
        int topExp = Math.max(3, (int) Math.ceil(Math.log10(max)));

        // Título e legenda
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 13f));
        g2.drawString("Tempo por operação (escala logarítmica)", x0, 20);
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 11f));
        int lx = x0;
        for (int j = 0; j < nCols; j++) {
            g2.setColor(CORES[j % CORES.length]);
            g2.fillRect(lx, 30, 11, 11);
            g2.setColor(getForeground());
            String rotulo = dados.getRotuloTamanho(j) + " registros";
            g2.drawString(rotulo, lx + 16, 40);
            lx += 16 + g2.getFontMetrics().stringWidth(rotulo) + 18;
        }

        // Linhas de grade e rótulos do eixo Y (1 ns, 10 ns, ... 1 s, 10 s)
        int passo = topExp > 8 ? 2 : 1;
        for (int k = 0; k <= topExp; k += passo) {
            int y = y0 + ph - (int) Math.round(ph * (double) k / topExp);
            g2.setColor(new Color(0, 0, 0, 30));
            g2.drawLine(x0, y, x0 + pw, y);
            g2.setColor(getForeground());
            String r = Tempo.formatar(Math.pow(10, k));
            g2.drawString(r, x0 - 8 - g2.getFontMetrics().stringWidth(r), y + 4);
        }
        g2.drawLine(x0, y0, x0, y0 + ph);
        g2.drawLine(x0, y0 + ph, x0 + pw, y0 + ph);

        // Barras
        double larguraGrupo = (double) pw / nOps;
        int barW = Math.max(6, (int) (larguraGrupo * 0.78 / nCols));
        g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 8.5f));
        for (int i = 0; i < nOps; i++) {
            double gx = x0 + larguraGrupo * i + (larguraGrupo - barW * nCols) / 2.0;
            for (int j = 0; j < nCols; j++) {
                double v = dados.getTempo(i, j);
                int bx = (int) Math.round(gx + j * barW);
                if (v < 0) { // não concluído (> 2 min)
                    g2.setColor(Color.RED);
                    g2.drawRect(bx + 1, y0, barW - 3, ph - 1);
                    g2.drawString("> 2 min", bx, y0 + 12);
                    continue;
                }
                double expoente = Math.log10(Math.max(v, 1));
                int bh = Math.max(1, (int) Math.round(ph * expoente / topExp));
                g2.setColor(CORES[j % CORES.length]);
                g2.fillRect(bx + 1, y0 + ph - bh, barW - 2, bh);
                if (barW >= 30) { // só escreve o valor se couber
                    g2.setColor(getForeground());
                    String t = Tempo.formatar(v);
                    g2.drawString(t, bx + (barW - g2.getFontMetrics().stringWidth(t)) / 2, y0 + ph - bh - 3);
                }
            }
            // Rótulo do grupo
            g2.setColor(getForeground());
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 11f));
            String nome = DadosRelatorio.ROTULOS_CURTOS[i];
            int tx = (int) (x0 + larguraGrupo * i + (larguraGrupo - g2.getFontMetrics().stringWidth(nome)) / 2);
            g2.drawString(nome, tx, y0 + ph + 18);
            g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 8.5f));
        }
        g2.dispose();
    }
}

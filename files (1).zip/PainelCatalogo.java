package view;

import controller.CatalogoController;
import model.Produto;
import model.Resultado;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

/**
 * Aba principal: carregar arquivo, ordenar, buscar e ver a tabela.
 * Toda a lógica está no CatalogoController; aqui só se montam componentes,
 * se capturam eventos e se mostra o que o controller devolve.
 */
public class PainelCatalogo extends JPanel {

    private static final Locale BR = Locale.forLanguageTag("pt-BR");

    private final CatalogoController controller;
    private final ProdutoTableModel modelo = new ProdutoTableModel();
    private final JTable tabela;

    private final JComboBox<String> cbArquivo = new JComboBox<>(CatalogoController.ARQUIVOS);
    private final JComboBox<String> cbCampo = new JComboBox<>(CatalogoController.CAMPOS);
    private final JComboBox<String> cbAlgoritmo = new JComboBox<>(CatalogoController.ALGORITMOS);
    private final JComboBox<String> cbTecnica = new JComboBox<>(CatalogoController.TECNICAS);
    private final JComboBox<String> cbCategoria = new JComboBox<>(); // editável: aceita digitar ou escolher
    private final JTextField txtId = new JTextField(8);

    private final JLabel lblArquivo = new JLabel("Nenhum arquivo carregado.");
    private final JLabel lblTempo = new JLabel("Tempo da última operação: -");
    private final JProgressBar barra = new JProgressBar();
    private final List<AbstractButton> botoes = new ArrayList<>();
    private boolean ocupado = false;

    public PainelCatalogo(CatalogoController controller) {
        this.controller = controller;
        setLayout(new BorderLayout(0, 6));

        tabela = criarTabela();
        cbCategoria.setEditable(true);
        cbCategoria.setPrototypeDisplayValue("Eletrodomésticos   ");

        add(criarControles(), BorderLayout.NORTH);
        add(new JScrollPane(tabela), BorderLayout.CENTER);
        add(criarRodape(), BorderLayout.SOUTH);
    }

    // ------------------------------------------------------------------
    // Montagem da tela
    // ------------------------------------------------------------------

    private JTable criarTabela() {
        JTable t = new JTable(modelo) {
            // Linhas zebradas: facilita ler tabelas com milhares de linhas
            @Override
            public Component prepareRenderer(TableCellRenderer r, int row, int col) {
                Component c = super.prepareRenderer(r, row, col);
                if (!isRowSelected(row)) {
                    Color bg = getBackground();
                    c.setBackground(row % 2 == 0 ? bg : new Color(
                            Math.max(0, bg.getRed() - 12), Math.max(0, bg.getGreen() - 10), Math.max(0, bg.getBlue() - 6)));
                }
                return c;
            }
        };
        t.setRowHeight(22);
        t.setFillsViewportHeight(true);

        // Preço em reais; ID e estoque sem separador de milhar
        final NumberFormat moeda = NumberFormat.getCurrencyInstance(BR);
        t.setDefaultRenderer(Double.class, new DefaultTableCellRenderer() {
            { setHorizontalAlignment(RIGHT); }
            @Override protected void setValue(Object v) {
                setText(v instanceof Number ? moeda.format(((Number) v).doubleValue()) : "");
            }
        });
        t.setDefaultRenderer(Integer.class, new DefaultTableCellRenderer() {
            { setHorizontalAlignment(RIGHT); }
            @Override protected void setValue(Object v) { setText(v == null ? "" : v.toString()); }
        });

        t.getColumnModel().getColumn(0).setPreferredWidth(70);
        t.getColumnModel().getColumn(1).setPreferredWidth(320);
        t.getColumnModel().getColumn(2).setPreferredWidth(150);
        t.getColumnModel().getColumn(3).setPreferredWidth(110);
        t.getColumnModel().getColumn(4).setPreferredWidth(80);

        // Clicar no cabeçalho ordena com NOSSO algoritmo (o escolhido no combo), não com o da JTable
        t.getTableHeader().setToolTipText("Clique em ID, Nome ou Preço para ordenar com o algoritmo escolhido");
        t.getTableHeader().addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                int col = tabela.columnAtPoint(e.getPoint());
                String campo = col == 0 ? "ID" : col == 1 ? "Nome" : col == 3 ? "Preço" : null;
                if (campo != null && !ocupado) {
                    cbCampo.setSelectedItem(campo);
                    ordenar();
                }
            }
        });
        return t;
    }

    private JPanel criarControles() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));

        JPanel arquivo = secao("1. Arquivo");
        arquivo.add(new JLabel("Arquivo:"));
        arquivo.add(cbArquivo);
        arquivo.add(botao("Carregar", this::carregar));
        arquivo.add(botao("Exportar lista atual...", this::exportar));
        arquivo.add(botao("Mostrar todos", this::mostrarTodos));

        JPanel ordenacao = secao("2. Ordenação (algoritmos implementados à mão)");
        ordenacao.add(new JLabel("Campo:"));
        ordenacao.add(cbCampo);
        ordenacao.add(new JLabel("Algoritmo:"));
        ordenacao.add(cbAlgoritmo);
        ordenacao.add(botao("Ordenar", this::ordenar));
        ordenacao.add(botao("Comparar os 2 algoritmos", this::compararAlgoritmos));

        JPanel busca = secao("3. Busca");
        busca.add(new JLabel("Técnica:"));
        busca.add(cbTecnica);
        busca.add(new JLabel("Id:"));
        busca.add(txtId);
        busca.add(botao("Buscar por id", this::buscarPorId));
        busca.add(botao("Comparar as 3 técnicas", this::compararBuscas));
        busca.add(Box.createHorizontalStrut(12));
        busca.add(new JLabel("Categoria:"));
        busca.add(cbCategoria);
        busca.add(botao("Buscar por categoria", this::buscarPorCategoria));

        p.add(arquivo);
        p.add(ordenacao);
        p.add(busca);
        return p;
    }

    private JPanel criarRodape() {
        JPanel p = new JPanel(new GridLayout(3, 1, 0, 2));
        p.setBorder(BorderFactory.createEmptyBorder(2, 8, 4, 8));
        lblTempo.setFont(lblTempo.getFont().deriveFont(Font.BOLD));
        barra.setPreferredSize(new Dimension(100, 8));
        p.add(lblTempo);
        p.add(lblArquivo);
        p.add(barra);
        return p;
    }

    private JPanel secao(String titulo) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        p.setBorder(BorderFactory.createTitledBorder(titulo));
        return p;
    }

    private JButton botao(String texto, Runnable acao) {
        JButton b = new JButton(texto);
        b.addActionListener(e -> { if (!ocupado) acao.run(); });
        botoes.add(b);
        return b;
    }

    // ------------------------------------------------------------------
    // Ações (cada uma chama o controller em segundo plano)
    // ------------------------------------------------------------------

    /** Chamado pela janela principal ao abrir: carrega o arquivo pequeno, se existir. */
    public void carregarInicial() {
        String arquivo = CatalogoController.ARQUIVOS[0];
        if (new File(CatalogoController.PASTA_DADOS, arquivo).exists()) {
            cbArquivo.setSelectedItem(arquivo);
            carregar();
        } else {
            lblArquivo.setText("Coloque os arquivos produtos_*.txt na pasta do projeto e clique em Carregar.");
        }
    }

    public void carregar() {
        String arquivo = (String) cbArquivo.getSelectedItem();
        executar(() -> controller.carregar(CatalogoController.PASTA_DADOS + File.separator + arquivo),
                r -> {
                    mostrar(r.getProdutos());
                    atualizarCategorias();
                    lblTempo.setText("Arquivo carregado. " + r.getResumo());
                });
    }

    public void exportar() {
        JFileChooser fc = new JFileChooser(new File("."));
        fc.setSelectedFile(new File("exportado.txt"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        String caminho = fc.getSelectedFile().getPath();
        executar(() -> {
            controller.exportar(caminho);
            return Resultado.mensagem("Arquivo exportado em " + caminho);
        }, r -> lblTempo.setText(r.getResumo()));
    }

    private void mostrarTodos() {
        mostrar(controller.getProdutosAtuais());
    }

    private void ordenar() {
        String campo = (String) cbCampo.getSelectedItem();
        String algoritmo = (String) cbAlgoritmo.getSelectedItem();
        executar(() -> controller.ordenar(campo, algoritmo), r -> {
            if (r.isConcluido()) mostrar(r.getProdutos());
            lblTempo.setText("Ordenação por " + campo + " - " + r.getResumo());
        });
    }

    /** Insertion x Merge no mesmo campo, lado a lado. */
    private void compararAlgoritmos() {
        String campo = (String) cbCampo.getSelectedItem();
        executar(() -> controller.compararOrdenacoes(campo), lista -> {
            Resultado simples = lista.get(0);
            Resultado eficiente = lista.get(1);
            String texto = "Por " + campo + ":  Insertion Sort = " + simples.getTempoFormatado()
                    + "   |   Merge Sort = " + eficiente.getTempoFormatado();
            if (simples.isConcluido() && eficiente.getTempoNs() > 0) {
                texto += String.format(BR, "   (Merge ≈ %.1f× mais rápido)", simples.getTempoNs() / eficiente.getTempoNs());
            }
            lblTempo.setText(texto);
        });
    }

    private void buscarPorId() {
        Integer id = lerId();
        if (id == null) return;
        String tecnica = (String) cbTecnica.getSelectedItem();
        executar(() -> controller.buscarPorId(id, tecnica), r -> {
            mostrar(r.getProdutos());
            lblTempo.setText(r.getResumo() + (r.getProdutos().isEmpty() ? "  -  id não encontrado" : ""));
        });
    }

    /** As 3 técnicas para o mesmo id: mostra os tempos médios lado a lado. */
    private void compararBuscas() {
        Integer id = lerId();
        if (id == null) return;
        executar(() -> controller.compararBuscasPorId(id), lista -> {
            StringBuilder sb = new StringBuilder("Id " + id + " (média de " + CatalogoController.REPETICOES + "):  ");
            for (int i = 0; i < lista.size(); i++) {
                if (i > 0) sb.append("   |   ");
                sb.append(CatalogoController.TECNICAS[i]).append(" = ").append(lista.get(i).getTempoFormatado());
            }
            mostrar(lista.get(0).getProdutos());
            lblTempo.setText(sb.toString());
        });
    }

    private void buscarPorCategoria() {
        String categoria = Objects.toString(cbCategoria.getEditor().getItem(), "").trim();
        if (categoria.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe ou escolha uma categoria.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return;
        }
        executar(() -> controller.buscarPorCategoria(categoria), r -> {
            mostrar(r.getProdutos());
            lblTempo.setText(r.getResumo());
        });
    }

    // ------------------------------------------------------------------
    // Apoio
    // ------------------------------------------------------------------

    private Integer lerId() {
        try {
            return Integer.valueOf(txtId.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Informe um id numérico.", "Atenção", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void mostrar(List<Produto> produtos) {
        modelo.setProdutos(produtos);
        lblArquivo.setText(String.format(BR, "Arquivo: %s   |   %,d produtos carregados   |   %,d exibidos",
                controller.getNomeArquivo(), controller.getTotal(), produtos.size()));
    }

    private void atualizarCategorias() {
        cbCategoria.removeAllItems();
        for (String c : controller.getCategorias()) cbCategoria.addItem(c);
        cbCategoria.setSelectedItem(null);
    }

    private <T> void executar(java.util.concurrent.Callable<T> tarefa, java.util.function.Consumer<T> aoConcluir) {
        ocupar(true);
        Tarefas.executar(this, tarefa, aoConcluir, () -> ocupar(false));
    }

    private void ocupar(boolean sim) {
        ocupado = sim;
        barra.setIndeterminate(sim);
        for (AbstractButton b : botoes) b.setEnabled(!sim);
    }
}

package view;

import model.Produto;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/** Liga a List<Produto> (Model) à JTable (View). */
public class ProdutoTableModel extends AbstractTableModel {
    private static final String[] COLUNAS = {"ID", "Nome", "Categoria", "Preço", "Estoque"};
    private List<Produto> produtos = new ArrayList<>();

    public void setProdutos(List<Produto> produtos) {
        this.produtos = produtos;
        fireTableDataChanged();
    }

    @Override public int getRowCount() { return produtos.size(); }
    @Override public int getColumnCount() { return COLUNAS.length; }
    @Override public String getColumnName(int col) { return COLUNAS[col]; }

    /** O tipo da coluna permite à JTable alinhar números à direita e usar nossos renderers. */
    @Override
    public Class<?> getColumnClass(int col) {
        switch (col) {
            case 0: return Integer.class;
            case 3: return Double.class;
            case 4: return Integer.class;
            default: return String.class;
        }
    }

    @Override
    public Object getValueAt(int linha, int col) {
        Produto p = produtos.get(linha);
        switch (col) {
            case 0: return p.getId();
            case 1: return p.getNome();
            case 2: return p.getCategoria();
            case 3: return p.getPreco();
            default: return p.getEstoque();
        }
    }
}

package controller;

import model.Buscador;
import model.Catalogo;
import model.Comparadores;
import model.GerenciadorArquivos;
import model.Ordenador;
import model.Produto;
import model.Resultado;
import model.TempoExcedidoException;

import java.io.IOException;
import java.util.ArrayList;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class CatalogoController {

    // Pasta onde estão os produtos_*.txt ("." = pasta do projeto)
    public static final String PASTA_DADOS = ".";

    public static final String[] ARQUIVOS = {"produtos_1000.txt", "produtos_10000.txt", "produtos_50000.txt"};
    public static final String[] CAMPOS = {"Preço", "Nome", "ID"};
    public static final String[] ALGORITMOS = {"Insertion Sort (simples)", "Merge Sort (eficiente)"};

    public static final String LINEAR = "Linear";
    public static final String BINARIA = "Binária";
    public static final String HASHMAP = "HashMap";
    public static final String[] TECNICAS = {LINEAR, BINARIA, HASHMAP};

    public static final int REPETICOES = 1000;
    public static final long LIMITE_NS = 120_000_000_000L; // 2 minutos

    private final Catalogo catalogo = new Catalogo();
    private int sink; // evita que a JVM elimine o laço de busca medido
    private String nomeArquivo = "";

    // ---------- Arquivos ----------

    public Resultado carregar(String caminho) throws IOException {
        List<Produto> lista = GerenciadorArquivos.ler(caminho);
        catalogo.carregar(lista);
        nomeArquivo = Paths.get(caminho).getFileName().toString();
        return new Resultado("Construção dos HashMaps", catalogo.getTempoConstrucaoNs(), catalogo.getAtual());
    }

    public void exportar(String caminho) throws IOException {
        exigirCarregado();
        GerenciadorArquivos.exportar(catalogo.getAtual(), caminho);
    }

    public List<Produto> getProdutosAtuais() {
        return catalogo.getAtual();
    }

    /** Lista como veio do arquivo (desordenada). Usada na demonstração. */
    public List<Produto> getProdutosOriginais() {
        return catalogo.getOriginal();
    }

    // ---------- Ordenação ----------

    /** Ordena e atualiza a lista exibida. Sempre parte da lista original (desordenada). */
    public Resultado ordenar(String campo, String algoritmo) {
        Comparator<Produto> cmp = comparadorDo(campo);
        boolean simples = algoritmo.startsWith("Insertion");
        Resultado r = medirOrdenacao(cmp, simples);
        if (r.isConcluido()) {
            catalogo.setAtual(r.getProdutos());
        }
        return r;
    }

    /** Mede uma ordenação sobre uma CÓPIA da lista original (não altera a lista exibida). */
    public Resultado medirOrdenacao(Comparator<Produto> cmp, boolean simples) {
        exigirCarregado();
        List<Produto> copia = catalogo.getCopiaOriginal();
        String nome = simples ? "Insertion Sort" : "Merge Sort";

        long inicio = System.nanoTime();
        try {
            if (simples) {
                Ordenador.insertionSort(copia, cmp, LIMITE_NS);
            } else {
                Ordenador.mergeSort(copia, cmp);
            }
        } catch (TempoExcedidoException e) {
            return Resultado.naoConcluido(nome);
        }
        long tempo = System.nanoTime() - inicio;
        return new Resultado(nome, tempo, copia);
    }

    // ---------- Busca por id ----------

    public Resultado buscarPorId(int id, String tecnica) {
        exigirCarregado();
        int[] ids = new int[REPETICOES];
        java.util.Arrays.fill(ids, id);
        double media = medirBuscaMedia(tecnica, ids);

        Produto p;
        if (LINEAR.equals(tecnica)) p = Buscador.buscaLinear(catalogo.getOriginal(), id);
        else if (BINARIA.equals(tecnica)) p = Buscador.buscaBinaria(catalogo.getListaOrdenadaPorId(), id);
        else p = Buscador.buscaHash(catalogo.getIndicePorId(), id);

        List<Produto> encontrados = new ArrayList<>();
        if (p != null) encontrados.add(p);
        return new Resultado("Busca " + tecnica + " (média de " + REPETICOES + ")", media, encontrados);
    }

    /** Tempo médio (ns) de uma busca, repetindo para cada id do vetor. */
    public double medirBuscaMedia(String tecnica, int[] ids) {
        exigirCarregado();
        int tipo = LINEAR.equals(tecnica) ? 0 : BINARIA.equals(tecnica) ? 1 : 2;

        List<Produto> lista = catalogo.getOriginal();
        // a lista ordenada é criada ANTES de cronometrar (esse custo não é da busca)
        List<Produto> ordenada = catalogo.getListaOrdenadaPorId();
        Map<Integer, Produto> mapa = catalogo.getIndicePorId();

        sink += executarLote(tipo, ids, lista, ordenada, mapa); // aquecimento da JVM

        // 5 rodadas cronometradas; fica a melhor (menos ruído de GC/JIT)
        double melhor = Double.MAX_VALUE;
        for (int rodada = 0; rodada < 5; rodada++) {
            long inicio = System.nanoTime();
            int acertos = executarLote(tipo, ids, lista, ordenada, mapa);
            long fim = System.nanoTime();
            sink += acertos;
            melhor = Math.min(melhor, (double) (fim - inicio) / ids.length);
        }
        return melhor;
    }

    private int executarLote(int tipo, int[] ids, List<Produto> lista,
                             List<Produto> ordenada, Map<Integer, Produto> mapa) {
        int acertos = 0;
        for (int id : ids) {
            Produto p;
            if (tipo == 0) p = Buscador.buscaLinear(lista, id);
            else if (tipo == 1) p = Buscador.buscaBinaria(ordenada, id);
            else p = Buscador.buscaHash(mapa, id);
            if (p != null) acertos++;
        }
        return acertos;
    }

    /** Sorteia ids que existem no arquivo (usado nas medições). */
    public int[] sortearIds(int quantidade, long semente) {
        exigirCarregado();
        List<Produto> lista = catalogo.getOriginal();
        Random rnd = new Random(semente);
        int[] ids = new int[quantidade];
        for (int i = 0; i < quantidade; i++) {
            ids[i] = lista.get(rnd.nextInt(lista.size())).getId();
        }
        return ids;
    }

    // ---------- Busca por categoria ----------

    public Resultado buscarPorCategoria(String categoria) {
        exigirCarregado();
        Map<String, List<Produto>> indice = catalogo.getIndicePorCategoria();
        String chave = resolverCategoria(categoria, indice);

        List<Produto> res = null;
        long inicio = System.nanoTime();
        for (int i = 0; i < REPETICOES; i++) {
            res = indice.get(chave);
        }
        double media = (double) (System.nanoTime() - inicio) / REPETICOES;

        if (res == null) res = new ArrayList<>();
        return new Resultado("Busca por categoria (HashMap, média de " + REPETICOES + ")", media, res);
    }

    /** Aceita "esportes" para "Esportes" (ignora maiúsculas/minúsculas). */
    private String resolverCategoria(String digitada, Map<String, List<Produto>> indice) {
        String d = digitada.trim();
        if (indice.containsKey(d)) return d;
        for (String chave : indice.keySet()) {
            if (chave.equalsIgnoreCase(d)) return chave;
        }
        return d;
    }

    // ---------- Comparações lado a lado (usadas pela interface) ----------

    /** Roda as 3 técnicas de busca por id para o mesmo id. */
    public List<Resultado> compararBuscasPorId(int id) {
        List<Resultado> resultados = new ArrayList<>();
        for (String tecnica : TECNICAS) {
            resultados.add(buscarPorId(id, tecnica));
        }
        return resultados;
    }

    /** Mede Insertion e Merge Sort no mesmo campo, sem alterar a lista exibida. */
    public List<Resultado> compararOrdenacoes(String campo) {
        Comparator<Produto> cmp = comparadorDo(campo);
        List<Resultado> resultados = new ArrayList<>();
        resultados.add(medirOrdenacao(cmp, true));
        resultados.add(medirOrdenacao(cmp, false));
        return resultados;
    }

    // ---------- Consultas simples para a tela ----------

    public String getNomeArquivo() { return nomeArquivo; }

    public int getTotal() { return catalogo.getOriginal().size(); }

    /** Categorias existentes (para o combo da tela), em ordem alfabética. */
    public List<String> getCategorias() {
        List<String> categorias = new ArrayList<>(catalogo.getIndicePorCategoria().keySet());
        categorias.sort(String::compareToIgnoreCase);
        return categorias;
    }

    // ---------- Apoio ----------

    private Comparator<Produto> comparadorDo(String campo) {
        if ("Nome".equals(campo)) return Comparadores.POR_NOME;
        if ("ID".equals(campo)) return Comparadores.POR_ID;
        return Comparadores.POR_PRECO;
    }


    private void exigirCarregado() {
        if (catalogo.isVazio()) {
            throw new IllegalStateException("Carregue um arquivo antes.");
        }
    }
}

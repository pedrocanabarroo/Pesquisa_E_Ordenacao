package view;

import javax.swing.*;
import java.awt.*;

/** Aba que mostra a arquitetura MVC do projeto: pensada para a apresentação ao professor. */
public class PainelEstrutura extends JPanel {

    public PainelEstrutura() {
        setLayout(new BorderLayout());
        JEditorPane html = new JEditorPane("text/html", montarHtml());
        html.setEditable(false);
        html.setCaretPosition(0);
        add(new JScrollPane(html), BorderLayout.CENTER);
    }

    private String montarHtml() {
        StringBuilder h = new StringBuilder();
        h.append("<html><body style='font-family:sans-serif; margin:12px'>");
        h.append("<h2>Arquitetura MVC do projeto</h2>");
        h.append("<p>O programa é dividido em três camadas. A regra que sustenta tudo: ");
        h.append("<b>Model e Controller não conhecem Swing</b>. Por isso o relatório e a demonstração ");
        h.append("rodam também sem tela (<code>java Main --relatorio</code> e <code>java Main --demo</code>).</p>");

        h.append("<table border='1' cellpadding='6' cellspacing='0'>");
        h.append("<tr><th>Camada</th><th>Pacote</th><th>Responsabilidade</th><th>Classes</th></tr>");
        h.append(linha("Model", "model",
                "Dados e regras: modelo do produto, leitura/escrita de arquivos, algoritmos de ordenação, "
                        + "técnicas de busca, índices HashMap e os dados das medições.",
                "Produto, Comparadores, GerenciadorArquivos, Ordenador, Buscador, Catalogo, "
                        + "Resultado, DadosRelatorio, Tempo, TempoExcedidoException"));
        h.append(linha("Controller", "controller",
                "Recebe os pedidos da View, chama o Model, mede os tempos (System.nanoTime) e devolve "
                        + "Resultados. Aplica as regras de coordenação (ex.: ordenar por id antes da busca binária).",
                "CatalogoController, RelatorioController, DemonstracaoController"));
        h.append(linha("View", "view",
                "Só interface Swing: captura eventos, chama o controller e exibe o que ele devolve. "
                        + "Operações pesadas rodam em SwingWorker para a tela não travar.",
                "TelaPrincipal, PainelCatalogo, PainelDesempenho, PainelDemonstracao, PainelEstrutura, "
                        + "GraficoBarras, ProdutoTableModel, Tarefas"));
        h.append("</table>");

        h.append("<h3>Fluxo de uma operação (exemplo: Ordenar)</h3>");
        h.append("<pre>");
        h.append("Usuário clica em \"Ordenar\"\n");
        h.append("  -&gt; PainelCatalogo (View)           captura o clique e lê os combos\n");
        h.append("    -&gt; CatalogoController            copia a lista original e mede com nanoTime\n");
        h.append("      -&gt; Ordenador (Model)           Insertion Sort ou Merge Sort + Comparator\n");
        h.append("    &lt;- Resultado (lista + tempo)\n");
        h.append("  &lt;- PainelCatalogo                  atualiza a JTable e o JLabel de tempo\n");
        h.append("</pre>");

        h.append("<h3>Decisões de projeto que valem explicar</h3><ul>");
        h.append("<li><b>Comparator</b>: o mesmo algoritmo ordena por nome, preço ou id.</li>");
        h.append("<li><b>Ordenação justa</b>: cada medição parte de uma cópia da lista desordenada.</li>");
        h.append("<li><b>Busca binária</b>: usa uma cópia ordenada por id, criada antes de cronometrar.</li>");
        h.append("<li><b>HashMap</b>: dois índices (por id e por categoria) montados na carga; "
                + "o custo de montagem é medido e aparece no relatório.</li>");
        h.append("<li><b>Limite de 2 minutos</b>: o Insertion Sort checa o tempo dentro do laço e "
                + "registra \"não concluído (&gt; 2 min)\".</li>");
        h.append("<li><b>Medição de busca</b>: média de 1.000 repetições, com aquecimento da JVM.</li>");
        h.append("</ul>");
        h.append("</body></html>");
        return h.toString();
    }

    private String linha(String camada, String pacote, String resp, String classes) {
        return "<tr><td><b>" + camada + "</b></td><td><code>" + pacote + "</code></td><td>"
                + resp + "</td><td>" + classes + "</td></tr>";
    }
}

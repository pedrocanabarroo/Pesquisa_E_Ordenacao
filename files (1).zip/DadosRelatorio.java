package model;

import java.util.Locale;

/**
 * Guarda os tempos medidos: uma linha por operação, uma coluna por tamanho de arquivo.
 * É só dado (Model): quem desenha o gráfico ou grava o relatorio.txt apenas lê daqui.
 */
public class DadosRelatorio {

    public static final double NAO_CONCLUIDO = -1;

    // Índices das linhas (iguais à tabela do enunciado)
    public static final int ORD_SIMPLES = 0;
    public static final int ORD_EFICIENTE = 1;
    public static final int BUSCA_LINEAR = 2;
    public static final int BUSCA_BINARIA = 3;
    public static final int BUSCA_HASH = 4;
    public static final int CONSTRUCAO_HASH = 5;

    public static final String[] OPERACOES = {
            "Ordenação simples (por preço)",
            "Ordenação eficiente (por preço)",
            "Busca linear por id (média)",
            "Busca binária por id (média)",
            "Busca por HashMap (média)",
            "Construção do HashMap"
    };

    /** Rótulos curtos para o eixo do gráfico. */
    public static final String[] ROTULOS_CURTOS = {
            "Ord. simples", "Ord. eficiente", "Busca linear",
            "Busca binária", "Busca HashMap", "Montar HashMap"
    };

    private final int[] tamanhos;
    private final double[][] tempos; // [operação][tamanho], em nanossegundos

    public DadosRelatorio(int[] tamanhos) {
        this.tamanhos = tamanhos.clone();
        this.tempos = new double[OPERACOES.length][tamanhos.length];
    }

    public void definir(int operacao, int coluna, double ns) { tempos[operacao][coluna] = ns; }
    public double getTempo(int operacao, int coluna) { return tempos[operacao][coluna]; }
    public int[] getTamanhos() { return tamanhos.clone(); }
    public int getNumOperacoes() { return OPERACOES.length; }

    /** "1.000", "10.000", "50.000" */
    public String getRotuloTamanho(int coluna) {
        return String.format(Locale.forLanguageTag("pt-BR"), "%,d", tamanhos[coluna]);
    }

    /** Tempo já formatado (ns, µs, ms, s) ou o aviso de que passou do limite. */
    public String formatar(int operacao, int coluna) {
        double v = tempos[operacao][coluna];
        return v < 0 ? "não concluído (> 2 min)" : Tempo.formatar(v);
    }
}

package view;

import controller.DemonstracaoController;
import model.Produto;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * Aba que executa TODO o sistema e narra cada passo (log + tabela).
 * Segue o MVC: só mostra o que o DemonstracaoController envia; nenhum algoritmo roda aqui.
 */
public class PainelDemonstracao extends JPanel {

    private final JTextArea txtLog = new JTextArea();
    private final ProdutoTableModel modelo = new ProdutoTableModel();
    private final JButton btnExecutar = new JButton("▶ Executar demonstração completa");
    private final JProgressBar barra = new JProgressBar();

    public PainelDemonstracao() {
        setLayout(new BorderLayout());

        txtLog.setEditable(false);
        txtLog.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        txtLog.setText("Clique em \"Executar demonstração completa\".\n"
                + "Os arquivos produtos_*.txt precisam estar na pasta do projeto.");

        btnExecutar.addActionListener(e -> executar());
        barra.setPreferredSize(new Dimension(200, 14));

        JPanel topo = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        topo.add(btnExecutar);
        topo.add(barra);

        JScrollPane painelTabela = new JScrollPane(new JTable(modelo));
        painelTabela.setBorder(BorderFactory.createTitledBorder("Produtos exibidos neste passo"));

        JSplitPane divisor = new JSplitPane(JSplitPane.VERTICAL_SPLIT, new JScrollPane(txtLog), painelTabela);
        divisor.setResizeWeight(0.65);

        add(topo, BorderLayout.NORTH);
        add(divisor, BorderLayout.CENTER);
    }

    private void executar() {
        btnExecutar.setEnabled(false);
        barra.setIndeterminate(true);
        txtLog.setText("");

        // O SwingWorker roda a demonstração em outra thread e "publica" textos e listas;
        // process() recebe tudo na thread da tela, onde é seguro mexer nos componentes.
        new SwingWorker<Void, Object>() {
            @Override
            protected Void doInBackground() throws Exception {
                new DemonstracaoController(
                        texto -> publish(texto),   // cada linha de log
                        lista -> publish(lista)    // cada lista para a tabela
                ).executar();
                return null;
            }

            @Override
            @SuppressWarnings("unchecked")
            protected void process(List<Object> pacotes) {
                for (Object o : pacotes) {
                    if (o instanceof String) {
                        txtLog.append(o + "\n");
                        txtLog.setCaretPosition(txtLog.getDocument().getLength());
                    } else {
                        modelo.setProdutos((List<Produto>) o);
                    }
                }
            }

            @Override
            protected void done() {
                barra.setIndeterminate(false);
                btnExecutar.setEnabled(true);
                try {
                    get(); // relança erros ocorridos em doInBackground
                } catch (Exception e) {
                    txtLog.append("\nERRO: " + Tarefas.mensagem(e) + "\n");
                    Tarefas.erro(PainelDemonstracao.this, e);
                }
            }
        }.execute();
    }
}
